# -*- coding: utf-8 -*-
"""倒计时窗口自检：确认到点会触发电源动作、点取消不会触发。"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import gui  # noqa: E402
import power  # noqa: E402

fired = []
gui.power.perform = lambda mode: (fired.append(mode), (True, "fake"))[1]
cancel_called = []
gui.power.cancel_shutdown = lambda: (cancel_called.append(1), (0, ""))[1]

import tkinter as tk  # noqa: E402

root = tk.Tk()
root.withdraw()

# ---- 1. 到点触发 ----
dlg = gui.CountdownDialog(root, "shutdown", 2, lambda why="": fired.append("cb:" + why), lambda m, l="info": print("   log:", m))
print("1) 已创建 2 秒倒计时，等待触发…")


def after_fire():
    print("   触发记录:", fired)
    assert fired and fired[0].startswith("cb:"), "倒计时到点没有回调"
    test_cancel()


def test_cancel():
    fired.clear()
    d = gui.CountdownDialog(root, "shutdown", 30, lambda why="": fired.append("cb"), lambda m, l="info": None)
    root.after(500, lambda: (d._cancel(), check_cancel()))


def check_cancel():
    print("2) 取消测试：cancel_shutdown 调用", len(cancel_called), "次；电源动作", fired)
    assert cancel_called, "取消时没有调用 shutdown /a"
    assert not fired, "取消后仍然执行了电源动作"
    root.destroy()


root.after(4000, after_fire)
root.mainloop()
print("COUNTDOWN TEST OK")
