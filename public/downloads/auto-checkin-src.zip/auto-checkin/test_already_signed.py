# -*- coding: utf-8 -*-
"""测试「已签到则跳过」逻辑：不会真的点击/截图。"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import engine  # noqa: E402
from config import Step, load_config  # noqa: E402

TPL = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates")
SIGN = os.path.join(TPL, "_t_sign.png")
DONE = os.path.join(TPL, "_t_done.png")
for p in (SIGN, DONE):
    open(p, "wb").close()  # 只需存在，匹配逻辑被 mock 掉

clicked = []
engine.click = lambda x, y, clicks=1, button="left": clicked.append((x, y))

cfg = load_config()
r = engine.Runner(cfg, log=lambda m, l="info": print("   [log]", m))


def fake_locate(sign_found, done_found):
    def _f(path, confidence=0.85, timeout=30.0, interval=1.0, log=None):
        if os.path.abspath(path) == os.path.abspath(SIGN):
            return ((100, 100), 0.95) if sign_found else (None, 0.42)
        if os.path.abspath(path) == os.path.abspath(DONE):
            return ((200, 200), 0.93) if done_found else (None, 0.31)
        return (None, 0.0)
    return _f


# ---- 1. 找不到签到按钮，但看到「已签到」→ 成功，且不点击
clicked.clear()
engine.locate_with_retry = fake_locate(False, True)
step = Step(type="click_image", template=SIGN, already_template=DONE)
ok, msg = r.run_step(step, "t")
print("1) 未找到按钮 + 检测到已签到 ->", ok, "|", msg, "| 点击次数:", len(clicked))
assert ok and "已签到" in msg and not clicked

# ---- 2. 两个都没找到 → 失败
clicked.clear()
engine.locate_with_retry = fake_locate(False, False)
ok2, msg2 = r.run_step(step, "t")
print("2) 两个都没找到 ->", ok2, "|", msg2)
assert not ok2

# ---- 3. 正常找到签到按钮 → 点击成功（不检查已签到图）
clicked.clear()
engine.locate_with_retry = fake_locate(True, False)
ok3, msg3 = r.run_step(step, "t")
print("3) 找到签到按钮 ->", ok3, "| 点击:", clicked)
assert ok3 and clicked == [(100, 100)]

# ---- 4. 没配「已签到」图时，行为与以前一致（失败）
clicked.clear()
engine.locate_with_retry = fake_locate(False, True)
ok4, msg4 = r.run_step(Step(type="click_image", template=SIGN), "t")
print("4) 未配置已签到图 ->", ok4, "|", msg4)
assert not ok4

# ---- 5. 步骤描述里能看出来
print("5) 步骤描述:", Step(type="click_image", template=SIGN,
                       already_template=DONE).describe())
assert "已签到时跳过" in Step(type="click_image", template=SIGN,
                          already_template=DONE).describe()

# ---- 6. 步骤编辑器能正常打开（含新行）
import tkinter as tk  # noqa: E402

import gui  # noqa: E402

root = tk.Tk()
# 注意不能 withdraw()：Toplevel 的 wait_visibility() 会一直等下去
root.geometry("300x200+1500+900")
root.update()
dlg = gui.StepDialog(root, Step(type="click_image", template=SIGN, already_template=DONE),
                     "点按钮（截图）")
root.after(500, lambda: (dlg.destroy(), root.quit()))
root.mainloop()
print("6) StepDialog 打开正常")

for p in (SIGN, DONE):
    os.remove(p)
print("ALREADY-SIGNED TEST OK")
