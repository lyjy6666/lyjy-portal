# -*- coding: utf-8 -*-
"""冒烟测试：校验找图、坐标换算、引擎步骤与 GUI 构造。"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import automation as A  # noqa: E402
from config import Step, Task, load_config, save_config  # noqa: E402
from engine import Runner  # noqa: E402

print("1) 虚拟屏幕:", A.virtual_screen())

img = A.screenshot()
print("2) 截图尺寸:", img.size)
mapper = A.ScreenMapper(img)
print("   缩放因子: %.3f, %.3f" % (mapper.scale_x, mapper.scale_y))

# 选一块"内容最丰富"的区域作为模板（纯色区域会到处误匹配）
import numpy as np  # noqa: E402

w, h = img.size
gray = np.asarray(img.convert("L"), dtype=np.float32)
best_std, best_xy = -1.0, (w // 2, h // 2)
for gy in range(2, 12):
    for gx in range(2, 16):
        y, x = int(h * gy / 14), int(w * gx / 18)
        patch = gray[max(0, y - 30):y + 30, max(0, x - 60):x + 60]
        if patch.size == 0:
            continue
        s = float(patch.std())
        if s > best_std:
            best_std, best_xy = s, (x, y)
print("   取样点:", best_xy, "标准差 %.1f" % best_std)
cx, cy = best_xy
crop = img.crop((cx - 60, cy - 30, cx + 60, cy + 30))
tpl_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates", "_smoke_tpl.png")
crop.save(tpl_path)

t0 = time.time()
pos, score = A.locate(tpl_path, confidence=0.9)
print("3) 找图结果:", pos, "相似度=%.3f" % score, "耗时 %.2fs" % (time.time() - t0))
assert pos is not None, "模板匹配失败"
expect = mapper.to_screen(cx, cy)
print("   期望坐标:", expect, "实际:", pos)
assert abs(pos[0] - expect[0]) <= 3 and abs(pos[1] - expect[1]) <= 3, "坐标换算偏差过大"

# 引擎：wait 步骤 + click_image（不真正点击）
cfg = load_config()
cfg.tasks.append(Task(name="smoke", kind="app", target="", steps=[
    Step(type="wait", seconds=0.2),
    Step(type="click_image", template=tpl_path, confidence=0.9, timeout=5, click_after=False),
]))
cfg.settings.retry_failed = False
r = Runner(cfg, log=lambda m, l="info": print("   [engine]", m))
ok, msg = r.run_step(cfg.tasks[-1].steps[1], "smoke")
print("4) 引擎步骤:", ok, msg)
assert ok, "引擎步骤执行失败"

# 4b) 发消息步骤（用假的点击/输入，避免真的操作屏幕）
import engine  # noqa: E402
from config import Step as _S  # noqa: E402

calls = []
engine.locate_with_retry = lambda *a, **k: ((100, 200), 0.99)
engine.click = lambda x, y, clicks=1, button="left": calls.append(("click", x, y))
engine.hotkey = lambda *ks: calls.append(("hotkey", ks))
engine.press = lambda k: calls.append(("press", k))
engine.write_text = lambda t: calls.append(("write", t))

ok, msg = r.run_step(_S(type="message", template=tpl_path, text="签到", send_key="enter"), "smoke")
print("4b) 发消息步骤:", ok, msg, calls)
assert ok, "发消息步骤执行失败"
assert ("click", 100, 200) in calls and ("hotkey", ("ctrl", "a")) in calls
assert ("write", "签到") in calls and ("press", "enter") in calls

ok2, msg2 = r.run_step(_S(type="message", template="不存在.png", text="签到"), "smoke")
print("   缺模板时:", ok2, msg2)
assert not ok2

# GUI 构造
import tkinter as tk  # noqa: E402
from gui import App, PresetDialog, TaskDialog, StepDialog, make_preset_task  # noqa: E402

root = tk.Tk()
root.withdraw()
app = App(root)
root.after(1500, root.destroy)
root.mainloop()
print("5) GUI 构造与销毁正常")

# 6) 新对话框：预设 + 任务编辑器 + 步骤编辑器(message)
for preset in ("click_app", "click_web", "msg_app", "blank"):
    t = make_preset_task(preset)
    assert isinstance(t, Task), preset
print("6) 预设任务生成正常:", [len(make_preset_task(p).steps) for p in
                               ("click_app", "click_web", "msg_app", "blank")])


def _open_and_close(builder, delay=400):
    holder = {}

    def go():
        holder["w"] = builder()
        root.after(delay, lambda: (holder["w"].destroy(), root.quit()))

    root.after(10, go)
    root.mainloop()


_open_and_close(lambda: PresetDialog(root))
print("   PresetDialog 打开正常")
_open_and_close(lambda: TaskDialog(root, make_preset_task("msg_app"), "新增任务"))
print("   TaskDialog 打开正常")
_open_and_close(lambda: StepDialog(root, _S(type="message", text="签到"), "发一条消息"))
print("   StepDialog(message) 打开正常")
_open_and_close(lambda: StepDialog(root, _S(type="wait", seconds=3), "等几秒"))
print("   StepDialog(wait) 打开正常")

os.remove(tpl_path)
print("SMOKE OK")
