# -*- coding: utf-8 -*-
"""开机自启。

优先在「启动」文件夹放一个标准 .lnk 快捷方式（不依赖 Windows Script Host，
比 .vbs 更不容易被安全软件 / 策略拦掉）；PowerShell 不可用时退回 .vbs。

所有操作都会写日志到 logs/autostart.log，方便排查"为什么没自启"。
"""
from __future__ import annotations

import os
import subprocess
import tempfile
import time

TASK_LNK = "AutoCheckin.lnk"
TASK_VBS = "AutoCheckin.vbs"
STARTUP_DIR = os.path.join(
    os.path.expandvars("%APPDATA%"), r"Microsoft\Windows\Start Menu\Programs\Startup"
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_DIR = os.path.join(BASE_DIR, "logs")
CREATE_NO_WINDOW = 0x08000000


# ------------------------------------------------------------------ 日志
def _log(msg: str) -> None:
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(os.path.join(LOG_DIR, "autostart.log"), "a", encoding="utf-8") as f:
            f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")
    except Exception:
        pass


# ------------------------------------------------------------------ 路径
def _main_py() -> str:
    return os.path.join(BASE_DIR, "main.py")


def _pythonw() -> str:
    import sys

    cand = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    if os.path.exists(cand):
        return cand
    cand2 = os.path.join(BASE_DIR, "venv-gui", "Scripts", "pythonw.exe")
    if os.path.exists(cand2):
        return cand2
    return sys.executable


def _lnk_path() -> str:
    return os.path.join(STARTUP_DIR, TASK_LNK)


def _vbs_path() -> str:
    return os.path.join(STARTUP_DIR, TASK_VBS)


def _powershell() -> str | None:
    root = os.environ.get("SystemRoot", r"C:\Windows")
    for sub in (r"System32\WindowsPowerShell\v1.0\powershell.exe",
                r"System32\powershell.exe"):
        p = os.path.join(root, sub)
        if os.path.exists(p):
            return p
    return None


# ------------------------------------------------------------------ 创建
def _create_lnk() -> tuple[bool, str]:
    """用 PowerShell 创建标准快捷方式"""
    ps = _powershell()
    if not ps:
        return False, "找不到 PowerShell"
    lnk = _lnk_path()
    py = _pythonw()
    main = _main_py()
    script = (
        '$ErrorActionPreference = "Stop"\n'
        '$ws = New-Object -ComObject WScript.Shell\n'
        f'$s = $ws.CreateShortcut("{lnk}")\n'
        f'$s.TargetPath = "{py}"\n'
        f'$s.Arguments = \'"{main}"\'\n'
        f'$s.WorkingDirectory = "{BASE_DIR}"\n'
        '$s.Description = "AutoCheckin"\n'
        '$s.WindowStyle = 7\n'
        '$s.Save()\n'
    )
    ps1 = os.path.join(tempfile.gettempdir(), "autocheckin_mklnk.ps1")
    try:
        with open(ps1, "w", encoding="ascii", errors="ignore") as f:
            f.write(script)
        r = subprocess.run(
            [ps, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", ps1],
            capture_output=True, text=True, errors="ignore",
            creationflags=CREATE_NO_WINDOW, timeout=60,
        )
        if r.returncode != 0:
            return False, (r.stderr or r.stdout or "").strip()[:200]
    except Exception as e:  # noqa
        return False, str(e)
    finally:
        try:
            os.remove(ps1)
        except Exception:
            pass
    if os.path.exists(lnk):
        return True, "快捷方式已创建"
    return False, "快捷方式未生成"


def _create_vbs() -> tuple[bool, str]:
    """退回方案：启动文件夹里的 .vbs 引导脚本"""
    py = _pythonw()
    main = _main_py()
    content = (
        'Set ws = CreateObject("WScript.Shell")\n'
        f'ws.CurrentDirectory = "{BASE_DIR}"\n'
        f'ws.Run """{py}"" ""{main}""", 0, False\n'
    )
    try:
        os.makedirs(STARTUP_DIR, exist_ok=True)
        with open(_vbs_path(), "w", encoding="ascii", errors="ignore") as f:
            f.write(content)
        return True, "vbs 引导脚本已创建"
    except Exception as e:  # noqa
        return False, str(e)


# ------------------------------------------------------------------ 对外接口
def enable() -> tuple[bool, str, str]:
    """开启开机自启，返回 (是否成功, 方式, 说明)"""
    ok, msg = _create_lnk()
    if ok:
        # 快捷方式成功就不再留 vbs，避免两个入口重复启动
        try:
            if os.path.exists(_vbs_path()):
                os.remove(_vbs_path())
        except Exception:
            pass
        _log(f"enable: 快捷方式 -> {_lnk_path()}")
        return True, "启动文件夹（快捷方式）", msg

    _log(f"enable: 快捷方式失败（{msg}），改用 vbs")
    ok2, msg2 = _create_vbs()
    if ok2:
        _log(f"enable: vbs -> {_vbs_path()}")
        return True, "启动文件夹（脚本）", msg2
    _log(f"enable: 全部失败（{msg} | {msg2}）")
    return False, "未启用", f"快捷方式：{msg}；脚本：{msg2}"


def disable() -> bool:
    ok = True
    for p in (_lnk_path(), _vbs_path()):
        try:
            if os.path.exists(p):
                os.remove(p)
        except Exception as e:  # noqa
            ok = False
            _log(f"disable: 删除失败 {p} -> {e}")
    _log("disable: done")
    return ok


def status() -> tuple[bool, str]:
    """返回 (是否已启用, 方式)"""
    if os.path.exists(_lnk_path()):
        return True, "启动文件夹（快捷方式）"
    if os.path.exists(_vbs_path()):
        return True, "启动文件夹（脚本）"
    return False, "未启用"


def is_enabled() -> bool:
    return status()[0]


def repair_if_needed() -> tuple[bool, str]:
    """启动时自检：设置里要求自启、但入口不见了，就自动补回来。
    返回 (是否做了修复, 方式/错误说明)
    """
    enabled, method = status()
    if enabled:
        return False, method
    ok, m, msg = enable()
    return ok, (m if ok else f"修复失败：{msg}")
