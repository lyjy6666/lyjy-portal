# -*- coding: utf-8 -*-
"""自动签到助手 —— 程序入口。

做了三件"保命"的事：
1. 单实例：防止开机时被重复启动（系统互斥量）。
2. 崩溃可查：pythonw 没有控制台，出错什么都看不到，所以异常一律写 logs/crash.log。
3. 启动重试：开机自启时桌面可能还没准备好，tkinter 会失败；失败后等 20 秒重试，最多 4 次。
"""
import ctypes
import json
import os
import sys
import threading
import time
import traceback
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

LOG_DIR = os.path.join(HERE, "logs")
MUTEX_NAME = "AutoCheckin_SingleInstance_v1"
HEARTBEAT = os.path.join(LOG_DIR, "instance.json")
MB_ICON_INFO = 0x40
HB_INTERVAL = 30       # 心跳间隔（秒）
HB_STALE = 300         # 超过 5 分钟没心跳就认为对方已经死了


def _diag(msg: str) -> None:
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(os.path.join(LOG_DIR, "crash.log"), "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}\n")
    except Exception:
        pass


def _single_instance() -> bool:
    """用系统互斥量保证只跑一个实例。返回 False 表示已经有实例在运行。"""
    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        # 故意不关闭句柄：进程存活期间一直持有这个互斥量
        kernel32.CreateMutexW(None, True, MUTEX_NAME)
        return ctypes.get_last_error() != 183  # 183 = ERROR_ALREADY_EXISTS
    except Exception:
        return True


def _heartbeat_loop() -> None:
    """每 30 秒写一次心跳，证明"我还活着" """
    while True:
        try:
            os.makedirs(LOG_DIR, exist_ok=True)
            tmp = HEARTBEAT + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"pid": os.getpid(), "ts": time.time()}, f)
            os.replace(tmp, HEARTBEAT)
        except Exception:
            pass
        time.sleep(HB_INTERVAL)


def _pid_alive(pid: int) -> bool:
    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        h = kernel32.OpenProcess(0x1000, False, int(pid))  # PROCESS_QUERY_LIMITED_INFORMATION
        if h:
            kernel32.CloseHandle(h)
            return True
        return False
    except Exception:
        return False


def _other_instance_really_alive() -> bool:
    """互斥量被占用时，再确认对方是不是真的活着。
    没有心跳文件时保持保守（认为活着），有心跳但已过期/进程已死则判定为残留。
    """
    try:
        if not os.path.exists(HEARTBEAT):
            return True
        with open(HEARTBEAT, "r", encoding="utf-8") as f:
            data = json.load(f)
        ts = float(data.get("ts", 0))
        pid = int(data.get("pid", 0))
        if time.time() - ts > HB_STALE:
            return False
        return _pid_alive(pid)
    except Exception:
        return True


def _focus_existing() -> bool:
    """已经有一个实例在跑时，把它的窗口叫出来（最小化了就还原），而不是弹窗打扰。"""
    try:
        from ctypes import wintypes

        user32 = ctypes.WinDLL("user32", use_last_error=True)
        EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
        found = []

        def _cb(hwnd, lparam):
            if user32.IsWindowVisible(hwnd):
                n = user32.GetWindowTextLengthW(hwnd)
                if n:
                    buf = ctypes.create_unicode_buffer(n + 1)
                    user32.GetWindowTextW(hwnd, buf, n + 1)
                    if "自动签到助手" in buf.value:
                        found.append(hwnd)
            return True

        user32.EnumWindows(EnumWindowsProc(_cb), 0)
        if not found:
            return False
        user32.ShowWindow(found[0], 9)  # SW_RESTORE
        user32.SetForegroundWindow(found[0])
        return True
    except Exception:
        return False


def _alert(text: str) -> None:
    try:
        ctypes.windll.user32.MessageBoxW(0, text, "自动签到助手", MB_ICON_INFO)
    except Exception:
        pass


def main() -> None:
    _diag("=== 启动 ===")

    if not _single_instance():
        if _other_instance_really_alive():
            _diag("检测到已有实例在运行，本次退出")
            _focus_existing()  # 把已经在跑的那个窗口叫出来，不弹窗打扰
            return
        # 只记日志，不弹窗：这条路径可能发生在无人值守的开机自启场景
        _diag("互斥量被占用，但对方心跳已过期或进程已不存在，判定为残留进程，本次接管启动")

    threading.Thread(target=_heartbeat_loop, daemon=True).start()

    for attempt in range(4):
        try:
            if attempt:
                _diag(f"第 {attempt} 次重试启动")
            from gui import main as gui_main

            gui_main()
            _diag("=== 正常退出 ===")
            return
        except Exception:
            _diag(f"启动失败（第 {attempt + 1} 次）：\n{traceback.format_exc()}")
            # 开机自启时桌面可能还没准备好，等一会再试
            time.sleep(20)

    _diag("重试 4 次仍失败，放弃启动")
    _alert("自动签到助手启动失败，已重试 4 次。\n详细信息见 logs\\crash.log")


if __name__ == "__main__":
    main()
