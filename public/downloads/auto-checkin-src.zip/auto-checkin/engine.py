# -*- coding: utf-8 -*-
"""任务执行引擎 + 每日定时调度。"""
from __future__ import annotations

import datetime as dt
import os
import threading
import time
import traceback
from typing import Callable, Dict, List, Optional, Tuple

from config import LOG_DIR, Task, load_state, save_state
from automation import (
    click,
    close_window,
    focus_window,
    hotkey,
    launch_app,
    launch_url,
    locate_with_retry,
    press,
    screenshot,
    scroll,
    window_rect,
    write_text,
)

LogCB = Callable[[str, str], None]


class Runner:
    """按配置顺序执行任务；可被中止。"""

    def __init__(self, cfg, log: LogCB = print):
        self.cfg = cfg
        self.log = log
        self._abort = threading.Event()
        self._running = False
        self.results: List[Dict] = []

    # ------------------------------------------------ 控制
    def stop(self) -> None:
        if self._running:
            self._abort.set()
            self.log("收到停止指令，当前步骤结束后中止…", "warn")

    @property
    def is_running(self) -> bool:
        return self._running

    def _sleep(self, seconds: float) -> bool:
        """可中断的等待，返回 False 表示被中止"""
        end = time.time() + max(seconds, 0)
        while time.time() < end:
            if self._abort.is_set():
                return False
            time.sleep(min(0.2, max(0.05, end - time.time())))
        return not self._abort.is_set()

    # ------------------------------------------------ 执行
    def run_step(self, step, task_name: str) -> Tuple[bool, str]:
        if self._abort.is_set():
            return False, "已中止"

        t = step.type
        if t == "wait":
            self.log(f"  · 等待 {step.seconds} 秒", "info")
            self._sleep(step.seconds)
            return True, "ok"

        if t == "click_image":
            if not step.template or not os.path.exists(step.template):
                return False, "还没截按钮的图（模板图片为空或文件不存在）"
            self.log(f"  · 查找图片 {os.path.basename(step.template)}（超时 {step.timeout}s）", "info")
            pos, score = locate_with_retry(
                step.template, confidence=step.confidence, timeout=step.timeout, log=self.log
            )
            if not pos:
                # 兜底：找不到"签到"按钮，但屏幕上出现了"已签到"标识 → 说明今天已经签过，不算失败
                already = getattr(step, "already_template", "")
                if already and os.path.exists(already):
                    self.log("  · 没找到签到按钮，检查是否已经签过了…", "info")
                    apos, ascore = locate_with_retry(
                        already, confidence=getattr(step, "already_confidence", 0.85),
                        timeout=3.0, log=self.log,
                    )
                    if apos:
                        self.log(f"  · 检测到「已签到」标识（相似度 {ascore:.2f}）→ 判定为今天已签到，跳过点击", "ok")
                        return True, "今天已签到过，自动跳过"
                return False, f"未找到图片（最佳匹配 {score:.2f} < {step.confidence:.2f}）"
            x, y = pos[0] + step.offset_x, pos[1] + step.offset_y
            self.log(f"  · 命中 ({x}, {y})，相似度 {score:.2f}", "ok")
            if step.click_after:
                click(x, y, clicks=max(1, step.clicks))
                self.log(f"  · 已点击 ({x}, {y})", "ok")
            return True, "ok"

        if t == "click_xy":
            self.log(f"  · 点击坐标 ({step.x}, {step.y})", "info")
            click(step.x, step.y, clicks=max(1, step.clicks))
            return True, "ok"

        if t == "hotkey":
            keys = [k for k in step.keys if k]
            self.log("  · 按键 " + "+".join(keys), "info")
            hotkey(*keys)
            return True, "ok"

        if t == "press":
            key = step.keys[0] if step.keys else "enter"
            self.log(f"  · 按下 {key}", "info")
            press(key)
            return True, "ok"

        if t == "type":
            self.log(f"  · 输入文本（{len(step.text)} 字符）", "info")
            write_text(step.text)
            return True, "ok"

        if t == "message":
            if not step.template or not os.path.exists(step.template):
                return False, "还没截输入框的图（模板图片为空或文件不存在）"
            # 1) 定位输入框
            self.log(f"  · 定位输入框 {os.path.basename(step.template)}（超时 {step.timeout}s）", "info")
            pos, score = locate_with_retry(
                step.template, confidence=step.confidence, timeout=step.timeout, log=self.log
            )
            if not pos:
                return False, f"未找到输入框（最佳匹配 {score:.2f} < {step.confidence:.2f}）"
            x, y = pos[0] + step.offset_x, pos[1] + step.offset_y
            self.log(f"  · 命中输入框 ({x}, {y})，相似度 {score:.2f}", "ok")
            click(x, y)
            self._sleep(0.4)
            # 2) 清空
            if getattr(step, "clear_input", True):
                hotkey("ctrl", "a")
                press("delete")
                self._sleep(0.2)
            # 3) 输入
            self.log(f"  · 输入消息“{step.text}”", "info")
            write_text(step.text)
            self._sleep(0.4)
            # 4) 发送
            key = (getattr(step, "send_key", "") or "enter").strip()
            if not key:
                return False, "未设置发送键"
            if "+" in key:
                hotkey(*[k.strip() for k in key.split("+") if k.strip()])
            else:
                press(key)
            self.log(f"  · 已发送（{key}）", "ok")
            self._sleep(0.8)
            return True, "ok"

        if t == "scroll":
            self.log(f"  · 滚轮 {step.clicks}", "info")
            scroll(step.clicks)
            return True, "ok"

        if t == "close":
            self.log(f"  · 关闭窗口 “{step.title}”", "info")
            close_window(step.title)
            return True, "ok"

        return False, f"未知步骤类型：{t}"

    def run_task(self, task: Task) -> Tuple[bool, str]:
        self.log(f"▶ 任务开始：{task.name}", "info")
        try:
            # 1. 启动
            if task.kind == "app":
                if not launch_app(task.target, task.args):
                    return False, f"启动失败，路径无效：{task.target}"
                self.log(f"  · 已启动程序：{task.target}", "ok")
            else:
                if not task.target:
                    return False, "未填写网址"
                launch_url(task.target, task.browser, task.browser_path)
                self.log(f"  · 已打开网页：{task.target}", "ok")

            if not self._sleep(task.launch_wait):
                return False, "已中止"

            # 2. 窗口置前
            if task.window_title:
                title = focus_window(task.window_title, maximize=task.maximize)
                if title:
                    self.log(f"  · 已置前窗口：{title}", "ok")
                    rect = window_rect(task.window_title)
                    if rect:
                        self.log(f"  · 窗口区域：{rect}", "debug")
                else:
                    self.log(f"  · 未找到窗口 “{task.window_title}”，继续尝试后续步骤", "warn")

            # 3. 步骤
            for i, step in enumerate(task.steps, 1):
                if self._abort.is_set():
                    return False, "已中止"
                self.log(f"  [{i}/{len(task.steps)}] {step.describe()}", "info")
                ok, msg = self.run_step(step, task.name)
                if not ok:
                    return False, f"第 {i} 步失败：{msg}"

            # 4. 成功验证（可选）
            if task.verify_template and os.path.exists(task.verify_template):
                pos, score = locate_with_retry(
                    task.verify_template,
                    confidence=task.verify_confidence,
                    timeout=task.verify_timeout,
                    log=self.log,
                )
                if not pos:
                    return False, f"签到结果验证失败（未找到验证图，相似度 {score:.2f}）"
                self.log(f"  · 验证成功，找到 “{os.path.basename(task.verify_template)}”（{score:.2f}）", "ok")

            # 5. 收尾
            if task.close_after and task.window_title:
                close_window(task.window_title)
                self.log(f"  · 已关闭窗口 “{task.window_title}”", "ok")

            self.log(f"✔ 任务完成：{task.name}", "ok")
            return True, "ok"

        except Exception as e:  # noqa
            self.log("  ! 异常：" + "".join(traceback.format_exception_only(type(e), e)).strip(), "error")
            return False, f"异常：{e}"

    def run_all(self, only: Optional[List[Task]] = None) -> List[Dict]:
        self._abort.clear()
        self._running = True
        self.results = []
        tasks = only if only is not None else [t for t in self.cfg.tasks if t.enabled]
        self.log(f"===== 开始执行，共 {len(tasks)} 个任务 =====", "info")
        try:
            for task in tasks:
                if self._abort.is_set():
                    break
                ok, msg = self.run_task(task)
                if not ok and self.cfg.settings.retry_failed and not self._abort.is_set():
                    self.log(f"↻ 重试任务：{task.name}", "warn")
                    if self._sleep(3):
                        ok, msg = self.run_task(task)
                self.results.append({"task": task.name, "ok": ok, "msg": msg})
                self.log(f"{'成功' if ok else '失败'}：{task.name}（{msg}）", "ok" if ok else "error")
                if not ok and self.cfg.settings.fail_screenshot:
                    try:
                        path = os.path.join(LOG_DIR, f"fail-{dt.datetime.now():%Y%m%d-%H%M%S}.png")
                        screenshot(path)
                        self.log(f"  · 已保存失败截图：{path}", "warn")
                    except Exception:
                        pass
                self._sleep(1)
        finally:
            self._running = False
            ok_count = sum(1 for r in self.results if r["ok"])
            self.log(f"===== 执行结束：成功 {ok_count}/{len(self.results)} =====",
                     "ok" if ok_count == len(self.results) else "warn")
        return self.results


class Scheduler(threading.Thread):
    """每日定时触发一次任务执行。"""

    def __init__(self, cfg_getter: Callable, runner_factory: Callable, log: LogCB = print,
                 busy_check: Optional[Callable[[], bool]] = None):
        super().__init__(daemon=True)
        self.cfg_getter = cfg_getter
        self.runner_factory = runner_factory
        self.log = log
        self.busy_check = busy_check
        self._stop_evt = threading.Event()
        # 从磁盘恢复"今天是否已跑过"，避免重启程序后又补跑一次
        self._last_run_date: Optional[str] = load_state().get("last_run_date")
        self.on_finish: Optional[Callable[[List[Dict]], None]] = None

    def stop(self):
        self._stop_evt.set()

    def _should_fire(self, now: dt.datetime, hhmm: str) -> bool:
        # 每天最多跑一次：跑过就不再触发，避免"任务跑得快，同一分钟内又被触发一遍"
        if self._last_run_date == now.strftime("%Y-%m-%d"):
            return False

        # 1) 准点触发（每 20 秒轮询一次，分钟级匹配）
        if now.strftime("%H:%M") == hhmm:
            return True

        cfg = self.cfg_getter()
        st = cfg.settings
        if not st.catch_up:
            return False
        # 2) 补跑：当天还没跑过，且"距离设定时间"在允许窗口内
        if self._last_run_date == now.strftime("%Y-%m-%d"):
            return False
        try:
            h, m = [int(x) for x in hhmm.split(":")]
            scheduled = now.replace(hour=h, minute=m, second=0, microsecond=0)
            delta = (now - scheduled).total_seconds()
            window = max(1, int(getattr(st, "catch_up_minutes", 60))) * 60
            return 0 < delta <= window
        except Exception:
            return False

    def run(self):
        self.log("定时调度已启动", "info")
        while not self._stop_evt.is_set():
            try:
                cfg = self.cfg_getter()
                if cfg.settings.auto_enabled and cfg.settings.daily_time:
                    now = dt.datetime.now()
                    if self._should_fire(now, cfg.settings.daily_time):
                        self._last_run_date = now.strftime("%Y-%m-%d")
                        save_state({"last_run_date": self._last_run_date})
                        self.log(f"⏰ 到达设定时间 {cfg.settings.daily_time}，开始自动执行", "ok")
                        if self.busy_check and self.busy_check():
                            self.log("⚠ 已有任务正在执行，跳过本次定时（避免两个流程抢鼠标键盘）", "warn")
                            continue
                        runner = self.runner_factory()
                        results = runner.run_all()
                        if self.on_finish:
                            self.on_finish(results)
            except Exception as e:  # noqa
                self.log(f"调度异常：{e}", "error")
            self._stop_evt.wait(20)
