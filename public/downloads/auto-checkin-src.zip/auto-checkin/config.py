# -*- coding: utf-8 -*-
"""配置模型与读写。所有配置保存在 config.json（与程序同目录）。"""
from __future__ import annotations

import json
import os
import uuid
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIR = os.path.join(BASE_DIR, "templates")
LOG_DIR = os.path.join(BASE_DIR, "logs")
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")
STATE_PATH = os.path.join(BASE_DIR, "state.json")

for _d in (TEMPLATE_DIR, LOG_DIR):
    os.makedirs(_d, exist_ok=True)


def new_id() -> str:
    return uuid.uuid4().hex[:8]


# ---------------------------------------------------------------- 步骤模型
# 步骤类型：
#   wait         等待 N 秒
#   click_image  在屏幕上找模板图片并点击（多尺度匹配）
#   click_xy     点击固定屏幕坐标
#   hotkey       发送组合键，如 ["ctrl", "s"]
#   press        发送单个按键，如 "enter"
#   type         输入文本
#   scroll       滚动鼠标滚轮
#   close        关闭指定标题的窗口
@dataclass
class Step:
    type: str = "click_image"
    # wait
    seconds: float = 2.0
    # click_image
    template: str = ""
    confidence: float = 0.85
    timeout: float = 30.0
    offset_x: int = 0
    offset_y: int = 0
    click_after: bool = True
    # click_xy
    x: int = 0
    y: int = 0
    # hotkey / press / type / scroll
    keys: List[str] = field(default_factory=list)
    text: str = ""
    clicks: int = 1
    # close
    title: str = ""
    # message（发一条消息）
    send_key: str = "enter"
    clear_input: bool = True
    # click_image 的可选兜底：找不到签到按钮时，若检测到"已签到"标识就当作已完成
    already_template: str = ""
    already_confidence: float = 0.85

    def describe(self) -> str:
        if self.type == "wait":
            return f"等待 {self.seconds} 秒"
        if self.type == "click_image":
            name = os.path.basename(self.template) if self.template else "(未选模板)"
            act = "点击" if self.click_after else "仅查找"
            extra = f" 偏移({self.offset_x},{self.offset_y})" if (self.offset_x or self.offset_y) else ""
            done = ""
            if getattr(self, "already_template", ""):
                done = f"，已签到时跳过（{os.path.basename(self.already_template)}）"
            return f"{act}图片 {name}（置信度{self.confidence}，超时{self.timeout}s）{extra}{done}"
        if self.type == "click_xy":
            return f"点击坐标 ({self.x}, {self.y}) x{self.clicks}"
        if self.type == "hotkey":
            return "按键 " + "+".join(self.keys)
        if self.type == "press":
            return "按下 " + (self.keys[0] if self.keys else "")
        if self.type == "message":
            name = os.path.basename(self.template) if self.template else "(未选输入框截图)"
            t = self.text if len(self.text) <= 14 else self.text[:14] + "…"
            return f"在 {name} 里发消息“{t}”，发送键 {self.send_key}"
        if self.type == "type":
            t = self.text if len(self.text) <= 18 else self.text[:18] + "…"
            return f"输入文本 “{t}”"
        if self.type == "scroll":
            return f"滚轮 {self.clicks}"
        if self.type == "close":
            return f"关闭窗口 “{self.title}”"
        return self.type


@dataclass
class Task:
    id: str = field(default_factory=new_id)
    name: str = "新任务"
    enabled: bool = True
    kind: str = "app"            # app | web
    target: str = ""             # exe 路径 或 网址
    browser: str = "system"      # system | chrome | edge | custom
    browser_path: str = ""
    args: str = ""               # 额外启动参数
    launch_wait: float = 8.0     # 启动后等待
    window_title: str = ""       # 窗口标题关键词（用于置前/最大化/关闭）
    maximize: bool = False
    close_after: bool = False    # 任务结束后关闭窗口
    steps: List[Step] = field(default_factory=list)
    verify_template: str = ""    # 可选：签到成功验证图
    verify_confidence: float = 0.85
    verify_timeout: float = 15.0

    def describe_target(self) -> str:
        return self.target or ("(未设置)" if self.kind == "app" else "(未设置网址)")


@dataclass
class Settings:
    daily_time: str = "09:00"        # 每日触发时间 HH:MM
    auto_enabled: bool = True        # 是否开启每日定时任务
    catch_up: bool = True            # 开机晚了是否补跑（当天未跑过则立即跑）
    retry_failed: bool = True        # 失败任务重试 1 次
    catch_up_minutes: int = 60       # 补跑时限：仅在超时后 N 分钟内补跑，避免首次启动时误触发
    shutdown_mode: str = "shutdown"  # shutdown | sleep | hibernate | none
    shutdown_delay: int = 60         # 延迟秒数，期间可取消
    ask_before_power: bool = True    # 是否弹出倒计时确认窗
    power_only_if_all_ok: bool = False  # 仅在全部任务成功时才关机
    manual_run_power: bool = False   # 手动「立即执行」完成后是否也执行关机动作（默认关，防误关）
    fail_screenshot: bool = True     # 失败时保存截图
    start_with_windows: bool = False
    minimize_on_start: bool = False


@dataclass
class Config:
    version: int = 1
    settings: Settings = field(default_factory=Settings)
    tasks: List[Task] = field(default_factory=list)


# ---------------------------------------------------------------- 读写
def _step_from_dict(d: Dict[str, Any]) -> Step:
    known = {f for f in Step.__dataclass_fields__}
    return Step(**{k: v for k, v in d.items() if k in known})


def _task_from_dict(d: Dict[str, Any]) -> Task:
    known = {f for f in Task.__dataclass_fields__}
    data = {k: v for k, v in d.items() if k in known}
    data["steps"] = [_step_from_dict(s) for s in d.get("steps", [])]
    return Task(**data)


def load_config() -> Config:
    if not os.path.exists(CONFIG_PATH):
        return Config()
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            raw = json.load(f)
    except Exception:
        return Config()
    st = Settings(**{k: v for k, v in (raw.get("settings") or {}).items()
                     if k in Settings.__dataclass_fields__})
    tasks = [_task_from_dict(t) for t in raw.get("tasks", [])]
    return Config(version=raw.get("version", 1), settings=st, tasks=tasks)


def load_state() -> Dict[str, Any]:
    """运行时状态（如"今天是否已跑过"），与用户配置分开存放。"""
    try:
        with open(STATE_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_state(state: Dict[str, Any]) -> None:
    try:
        with open(STATE_PATH, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def save_config(cfg: Config) -> None:
    data = {
        "version": cfg.version,
        "settings": asdict(cfg.settings),
        "tasks": [asdict(t) for t in cfg.tasks],
    }
    tmp = CONFIG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, CONFIG_PATH)
