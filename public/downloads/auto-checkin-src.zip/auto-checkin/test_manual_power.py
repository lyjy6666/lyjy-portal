# -*- coding: utf-8 -*-
"""手动执行关机选项自检：不会真的关机（把场景设成 none / 无任务）。"""
import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import tkinter as tk  # noqa: E402

import config as C  # noqa: E402
import gui  # noqa: E402

BACKUP = C.CONFIG_PATH + ".testbak"
shutil.copy2(C.CONFIG_PATH, BACKUP)

try:
    root = tk.Tk()
    root.withdraw()
    app = gui.App(root)
    print("1) 勾选框存在，默认值 =", app.var_run_power.get(),
          "（配置 manual_run_power =", app.cfg.settings.manual_run_power, ")")
    assert app.var_run_power.get() == bool(app.cfg.settings.manual_run_power)

    # 打开勾选 → 应写进配置
    app.var_run_power.set(True)
    app._on_run_power_toggle()
    import json
    saved = json.load(open(C.CONFIG_PATH, encoding="utf-8"))["settings"]["manual_run_power"]
    print("2) 勾选后已持久化 manual_run_power =", saved)
    assert saved is True

    # 场景一：勾选项 + 关机模式 → 应进入关机判断（这里改成 none，只验证分支不真关）
    logs = []
    app.log = lambda m, l="info": logs.append(f"[{l}] {m}")
    app.cfg.settings.shutdown_mode = "none"
    app._after_run([{"task": "t", "ok": True, "msg": "ok"}], skip_power=False)
    print("3) skip_power=False：", [x for x in logs if "关机判断" in x or "不动作" in x])
    assert any("关机判断" in x for x in logs), "勾选后没有进入关机判断"

    # 场景二：未勾选 + skip_power=True → 不应进入关机判断
    logs.clear()
    app.var_run_power.set(False)
    app._on_run_power_toggle()
    app._after_run([{"task": "t", "ok": True, "msg": "ok"}], skip_power=True)
    print("4) skip_power=True 且未勾选：", logs)
    assert not any("关机判断" in x for x in logs), "未勾选却进入了关机判断"
    assert any("不关机" in x for x in logs)

    root.destroy()
    print("MANUAL POWER TEST OK")
finally:
    shutil.move(BACKUP, C.CONFIG_PATH)
    print("（配置已还原为测试前状态）")
