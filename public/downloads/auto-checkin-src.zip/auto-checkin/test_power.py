# -*- coding: utf-8 -*-
"""关机链路自检：不会真的关机（monkeypatch 掉 shutdown 调用）。"""
import os
import queue
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import power  # noqa: E402

# ---------- 1. 命令拼装 + 失败重试 ----------
calls = []


class FakeResult:
    def __init__(self, rc, out=b""):
        self.returncode = rc
        self.stdout = out
        self.stderr = b""


def fake_run(args, **kw):
    calls.append(args)
    if args[0] == "shutdown" and "/s" in args:
        return FakeResult(0 if len(calls) >= 2 else 1115, "关机被策略禁止".encode("gbk"))
    return FakeResult(0)


power.subprocess.run = fake_run
ok, msg = power.perform("shutdown")
print("1) 失败后重试:", ok, "|", msg, "| 调用次数:", len(calls))
print("   首次参数:", calls[0])
assert calls[0] == ["shutdown", "/s", "/t", "0", "/f"], "关机参数不对"
assert ok and len(calls) == 2, "重试逻辑不对"

# ---------- 2. 全部失败时的返回 ----------
calls.clear()
power.subprocess.run = lambda args, **kw: (calls.append(args), FakeResult(5, "拒绝访问".encode("gbk")))[1]
ok2, msg2 = power.perform("shutdown")
print("2) 持续失败:", ok2, "|", msg2)
assert not ok2 and "rc=5" in msg2

# ---------- 3. none 模式 ----------
ok3, msg3 = power.perform("none")
print("3) none 模式:", ok3, msg3)
assert ok3

# ---------- 4. 主线程事件队列 → 关机判断 ----------
import tkinter as tk  # noqa: E402

from gui import App  # noqa: E402

root = tk.Tk()
root.withdraw()
app = App(root)
app.cfg.settings.shutdown_mode = "none"      # 测试期间绝不真的关机
app.cfg.settings.manual_run_power = True     # 让手动结果也走关机判断分支

captured = []
app.log = lambda m, l="info": captured.append(f"[{l}] {m}")

app.event_q.put(("run_done", ([{"task": "t1", "ok": True, "msg": "ok"}], False)))


def check():
    root.after(400, finish)


def finish():
    hits = [c for c in captured if "关机判断" in c or "不动作" in c or "本轮结果" in c]
    print("4) 事件队列→关机判断:")
    for h in hits:
        print("   ", h)
    assert any("关机判断" in c for c in captured), "关机判断没被调用（跨线程事件没送达）"
    assert any("不动作" in c for c in captured), "mode=none 分支没走到"
    root.destroy()


root.after(300, check)
root.mainloop()
print("POWER TEST OK")
