# -*- coding: utf-8 -*-
"""图形界面：任务编排 / 定时设置 / 运行日志 / 模板截图。"""
from __future__ import annotations

import datetime as dt
import os
import queue
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import autostart
import power
from automation import ScreenMapper, screenshot
from config import (
    LOG_DIR,
    TEMPLATE_DIR,
    Step,
    Task,
    load_config,
    new_id,
    save_config,
)
from engine import Runner, Scheduler

STEP_TYPES = [
    ("wait", "等几秒"),
    ("click_image", "点按钮（截图）"),
    ("message", "发一条消息"),
    ("click_xy", "点固定坐标"),
    ("hotkey", "按组合键"),
    ("press", "按单个键"),
    ("type", "输入文字"),
    ("scroll", "滚滚轮"),
    ("close", "关窗口"),
]
STEP_LABEL = dict(STEP_TYPES)
LABEL_TO_KEY = {label: key for key, label in STEP_TYPES}

_LOG_LOCK = threading.Lock()  # 多线程同时写日志会写出半行乱码，加锁串行化

# 每种步骤的一句大白话说明，显示在步骤编辑器顶部
STEP_HINT = {
    "wait": "什么都不做，纯等几秒。用来等软件启动、等网页加载完。",
    "click_image": "在屏幕上找你截好的按钮图片，找到就点它。绝大多数「签到」按钮用这个。"
                   "如果今天已经签过、按钮变成了「已签到」，可以在下面补一张「已签到的样子」，程序就不会误报失败。",
    "message": "先点一下输入框（用截图定位），再输入内容并发送。适合要「发一句话」才算签到的软件。",
    "click_xy": "点屏幕上的固定位置。不太推荐——窗口一挪位置就点歪了。",
    "hotkey": "按组合键，例如 ctrl+s、alt+f4（多个键用空格分开）。",
    "press": "按单个键，例如 enter（回车）、f5（刷新）、esc。",
    "type": "输入一段文字，中文也可以。",
    "scroll": "滚鼠标滚轮，正数向上、负数向下。",
    "close": "关掉标题里包含这段文字的窗口。",
}


# ------------------------------------------------------------------ 截图工具
class Snipper(tk.Toplevel):
    """全屏框选截图，保存为模板图片。"""

    def __init__(self, master, on_done):
        super().__init__(master)
        self.on_done = on_done
        self.attributes("-fullscreen", True)
        self.attributes("-alpha", 0.30)
        self.attributes("-topmost", True)
        self.configure(bg="black", cursor="cross")
        self.canvas = tk.Canvas(self, bg="black", highlightthickness=0, cursor="cross")
        self.canvas.pack(fill="both", expand=True)
        self.canvas.create_text(
            self.winfo_screenwidth() // 2,
            40,
            text="拖拽鼠标框选「签到按钮」区域，Esc 取消",
            fill="white",
            font=("Microsoft YaHei UI", 16, "bold"),
        )
        self.start = None
        self.rect = None
        self.canvas.bind("<ButtonPress-1>", self.on_down)
        self.canvas.bind("<B1-Motion>", self.on_move)
        self.canvas.bind("<ButtonRelease-1>", self.on_up)
        self.bind("<Escape>", lambda e: self.destroy())

    def on_down(self, e):
        self.start = (e.x_root, e.y_root)
        if self.rect:
            self.canvas.delete(self.rect)
        self.rect = self.canvas.create_rectangle(0, 0, 0, 0, outline="#ff3b30", width=3)

    def on_move(self, e):
        if not self.start:
            return
        x0, y0 = self.start
        self.canvas.coords(self.rect, x0, y0, e.x_root, e.y_root)

    def on_up(self, e):
        if not self.start:
            return
        x0, y0 = self.start
        x1, y1 = e.x_root, e.y_root
        self.start = None
        left, top = min(x0, x1), min(y0, y1)
        right, bottom = max(x0, x1), max(y0, y1)
        if right - left < 5 or bottom - top < 5:
            messagebox.showwarning("提示", "框选区域太小，请重新框选")
            return
        self.withdraw()
        self.update()
        self.after(350, lambda: self._capture(left, top, right, bottom))

    def _capture(self, left, top, right, bottom):
        try:
            img = screenshot()
            mapper = ScreenMapper(img)
            px0, py0 = mapper.to_image(left, top)
            px1, py1 = mapper.to_image(right, bottom)
            px0, py0 = max(0, px0), max(0, py0)
            px1, py1 = min(img.size[0], px1), min(img.size[1], py1)
            crop = img.crop((px0, py0, px1, py1))
            default = os.path.join(TEMPLATE_DIR, f"tpl-{dt.datetime.now():%Y%m%d-%H%M%S}.png")
            path = filedialog.asksaveasfilename(
                parent=self.master,
                title="保存模板图片",
                defaultextension=".png",
                initialfile=os.path.basename(default),
                initialdir=TEMPLATE_DIR,
                filetypes=[("PNG 图片", "*.png")],
            )
            if not path:
                self.destroy()
                return
            crop.save(path)
            if self.on_done:
                self.on_done(path)
        except Exception as exc:  # noqa
            messagebox.showerror("截图失败", str(exc))
        finally:
            self.destroy()


# ------------------------------------------------------------------ 步骤编辑器
class StepDialog(tk.Toplevel):
    """单个步骤编辑器：每种类型都有一句大白话说明 + 只显示相关字段。"""

    def __init__(self, master, step: Step, title="编辑步骤"):
        super().__init__(master)
        self.title(title)
        self.resizable(False, False)
        self.transient(master)
        self.configure(bg="#f5f5f5")
        self.step = step
        self.result: Step | None = None

        self.vars = {
            "type": tk.StringVar(value=STEP_LABEL.get(step.type, STEP_LABEL["click_image"])),
            "seconds": tk.StringVar(value=str(step.seconds)),
            "template": tk.StringVar(value=step.template),
            "confidence": tk.StringVar(value=str(step.confidence)),
            "timeout": tk.StringVar(value=str(step.timeout)),
            "offset_x": tk.StringVar(value=str(step.offset_x)),
            "offset_y": tk.StringVar(value=str(step.offset_y)),
            "click_after": tk.BooleanVar(value=step.click_after),
            "x": tk.StringVar(value=str(step.x)),
            "y": tk.StringVar(value=str(step.y)),
            "clicks": tk.StringVar(value=str(step.clicks)),
            "keys": tk.StringVar(value=" ".join(step.keys)),
            "text": tk.StringVar(value=step.text),
            "title": tk.StringVar(value=step.title),
            "send_key": tk.StringVar(value=getattr(step, "send_key", "") or "enter"),
            "clear_input": tk.BooleanVar(value=getattr(step, "clear_input", True)),
            "already_template": tk.StringVar(value=getattr(step, "already_template", "")),
        }

        frm = ttk.Frame(self, padding=14)
        frm.pack(fill="both", expand=True)
        r = 0

        ttk.Label(frm, text="这一步要做什么：", font=("Microsoft YaHei UI", 10, "bold")).grid(
            row=r, column=0, sticky="w", pady=(0, 6))
        cb = ttk.Combobox(frm, textvariable=self.vars["type"], state="readonly", width=26,
                          values=[label for _, label in STEP_TYPES])
        cb.grid(row=r, column=1, columnspan=4, sticky="w", pady=(0, 6))
        cb.bind("<<ComboboxSelected>>", lambda e: self._refresh())
        r += 1

        self.hint = ttk.Label(frm, text="", foreground="#0a7d33", wraplength=540,
                              justify="left", font=("Microsoft YaHei UI", 9))
        self.hint.grid(row=r, column=0, columnspan=5, sticky="w", pady=(0, 10))
        r += 1

        self.rows = {}
        self.rows["seconds"] = self._row(frm, r, "等待秒数：", "seconds"); r += 1
        self.rows["template"] = self._template_row(frm, r); r += 1
        self.rows["already"] = self._template_row(
            frm, r, key="already_template", label="已签到的样子："); r += 1
        note = ttk.Label(frm, text="↑ 选填：没找到上面的按钮时，若检测到这张图，就当作今天已经签过，不算失败",
                         foreground="#888", font=("Microsoft YaHei UI", 9))
        note.grid(row=r, column=1, columnspan=4, sticky="w")
        self.rows["already_note"] = (note,)
        r += 1
        self.rows["confidence"] = self._row(frm, r, "长得要多像才算找到(0-1)：", "confidence"); r += 1
        self.rows["timeout"] = self._row(frm, r, "最多找几秒：", "timeout"); r += 1
        self.rows["offset"] = self._row2(frm, r, "点歪了？微调 X：", "offset_x", "Y：", "offset_y"); r += 1

        lbl = ttk.Label(frm, text="找到后点它：")
        chk = ttk.Checkbutton(frm, variable=self.vars["click_after"])
        lbl.grid(row=r, column=0, sticky="w", pady=4)
        chk.grid(row=r, column=1, sticky="w", pady=4)
        self.rows["click_after"] = (lbl, chk)
        r += 1

        self.lbl_text = ttk.Label(frm, text="内容：")
        ent_text = ttk.Entry(frm, textvariable=self.vars["text"], width=34)
        self.lbl_text.grid(row=r, column=0, sticky="w", pady=4)
        ent_text.grid(row=r, column=1, columnspan=4, sticky="w", pady=4)
        self.rows["text"] = (self.lbl_text, ent_text)
        r += 1

        lbl_sk = ttk.Label(frm, text="发送键：")
        ent_sk = ttk.Entry(frm, textvariable=self.vars["send_key"], width=12)
        lbl_sk_hint = ttk.Label(frm, text="一般填 enter；有些软件换行才发送就填 ctrl+enter",
                                foreground="#888", font=("Microsoft YaHei UI", 9))
        lbl_sk.grid(row=r, column=0, sticky="w", pady=4)
        ent_sk.grid(row=r, column=1, sticky="w", pady=4)
        lbl_sk_hint.grid(row=r, column=2, columnspan=3, sticky="w")
        self.rows["send_key"] = (lbl_sk, ent_sk, lbl_sk_hint)
        r += 1

        lbl_ci = ttk.Label(frm, text="发送前清空输入框：")
        chk_ci = ttk.Checkbutton(frm, variable=self.vars["clear_input"])
        lbl_ci.grid(row=r, column=0, sticky="w", pady=4)
        chk_ci.grid(row=r, column=1, sticky="w", pady=4)
        self.rows["clear_input"] = (lbl_ci, chk_ci)
        r += 1

        self.rows["xy"] = self._row2(frm, r, "坐标 X：", "x", "Y：", "y"); r += 1
        self.rows["clicks"] = self._row(frm, r, "点击次数：", "clicks"); r += 1
        self.rows["keys"] = self._row(frm, r, "按键（空格分隔）：", "keys"); r += 1
        self.rows["title"] = self._row(frm, r, "窗口标题包含：", "title"); r += 1

        btns = ttk.Frame(frm)
        btns.grid(row=r, column=0, columnspan=5, pady=(16, 0))
        ttk.Button(btns, text="确定", width=12, command=self._ok).pack(side="left", padx=5)
        ttk.Button(btns, text="取消", width=12, command=self.destroy).pack(side="left", padx=5)
        ttk.Button(btns, text="先测试这一步", width=14, command=self._test).pack(side="left", padx=5)

        self._refresh()
        self.wait_visibility()
        self.grab_set()
        self.focus_force()

    # --- 构造辅助 -------------------------------------------------
    def _row(self, parent, row, label, key, width=34):
        lbl = ttk.Label(parent, text=label)
        ent = ttk.Entry(parent, textvariable=self.vars[key], width=width)
        lbl.grid(row=row, column=0, sticky="w", pady=4)
        ent.grid(row=row, column=1, columnspan=4, sticky="w", pady=4)
        return (lbl, ent)

    def _row2(self, parent, row, l1, k1, l2, k2):
        lbl = ttk.Label(parent, text=l1)
        e1 = ttk.Entry(parent, textvariable=self.vars[k1], width=8)
        l2w = ttk.Label(parent, text=l2)
        e2 = ttk.Entry(parent, textvariable=self.vars[k2], width=8)
        lbl.grid(row=row, column=0, sticky="w", pady=4)
        e1.grid(row=row, column=1, sticky="w", pady=4)
        l2w.grid(row=row, column=2, sticky="w", padx=(10, 0))
        e2.grid(row=row, column=3, sticky="w", pady=4)
        return (lbl, e1, l2w, e2)

    def _template_row(self, parent, row, key="template", label="它的截图："):
        lbl = ttk.Label(parent, text=label)
        ent = ttk.Entry(parent, textvariable=self.vars[key], width=26)
        b1 = ttk.Button(parent, text="选文件", width=8,
                        command=lambda: self._pick_template(key))
        b2 = ttk.Button(parent, text="现在去屏幕截", width=14,
                        command=lambda: self._snip_template(key))
        lbl.grid(row=row, column=0, sticky="w", pady=4)
        ent.grid(row=row, column=1, columnspan=2, sticky="w", pady=4)
        b1.grid(row=row, column=3, sticky="w", padx=(6, 0))
        b2.grid(row=row, column=4, sticky="w", padx=(6, 0))
        return (lbl, ent, b1, b2)

    def _pick_template(self, key="template"):
        path = filedialog.askopenfilename(
            parent=self, title="选择截图模板", initialdir=TEMPLATE_DIR,
            filetypes=[("图片", "*.png;*.jpg;*.bmp"), ("所有文件", "*.*")])
        if path:
            self.vars[key].set(path)

    def _snip_template(self, key="template"):
        Snipper(self, on_done=lambda p: self.vars[key].set(p))

    def _type_key(self) -> str:
        """下拉框显示中文，内部用英文 key"""
        return LABEL_TO_KEY.get(self.vars["type"].get(), "click_image")

    def _refresh(self):
        t = self._type_key()
        self.hint.configure(text=STEP_HINT.get(t, ""))
        self.lbl_text.configure(text="发送内容：" if t == "message" else "要输入的文字：")
        visible = {
            "wait": ["seconds"],
            "click_image": ["template", "already", "already_note", "confidence", "timeout",
                            "offset", "click_after", "clicks"],
            "message": ["template", "confidence", "timeout", "offset", "text", "send_key", "clear_input"],
            "click_xy": ["xy", "clicks"],
            "hotkey": ["keys"],
            "press": ["keys"],
            "type": ["text"],
            "scroll": ["clicks"],
            "close": ["title"],
        }.get(t, [])
        for key, widgets in self.rows.items():
            for w in widgets:
                if key in visible:
                    w.grid()
                else:
                    w.grid_remove()

    # --- 取值 -----------------------------------------------------
    def _build(self) -> Step | None:
        v = self.vars
        t = self._type_key()

        def f(key, default):
            try:
                return float(v[key].get())
            except Exception:
                return default

        def i(key, default=0):
            try:
                return int(float(v[key].get()))
            except Exception:
                return default

        step = Step(
            type=t,
            seconds=f("seconds", 2.0),
            template=v["template"].get().strip(),
            confidence=min(0.99, max(0.5, f("confidence", 0.85))),
            timeout=max(1.0, f("timeout", 30.0)),
            offset_x=i("offset_x"), offset_y=i("offset_y"),
            click_after=v["click_after"].get(),
            x=i("x"), y=i("y"),
            clicks=max(1, i("clicks", 1)) if t != "scroll" else i("clicks", 1),
            keys=[k for k in v["keys"].get().replace("+", " ").split() if k],
            text=v["text"].get(),
            title=v["title"].get().strip(),
            send_key=(v["send_key"].get().strip() or "enter"),
            clear_input=v["clear_input"].get(),
            already_template=v["already_template"].get().strip(),
            already_confidence=min(0.99, max(0.5, f("confidence", 0.85))),
        )
        if t in ("click_image", "message") and not step.template:
            messagebox.showwarning("还差一步", "请先点「现在去屏幕截」，把按钮/输入框截下来")
            return None
        if t == "message" and not step.text.strip():
            messagebox.showwarning("还差一步", "请填写要发送的内容，例如：签到")
            return None
        return step

    def _ok(self):
        step = self._build()
        if step is None:
            return
        self.result = step
        self.destroy()

    def _test(self):
        step = self._build()
        if step is None:
            return
        self.iconify()
        try:
            self.master.iconify()
        except Exception:
            pass

        def work():
            from engine import Runner

            try:
                r = Runner(load_config(), log=lambda m, l="info": None)
                ok, msg = r.run_step(step, "测试")
            except Exception as exc:  # noqa
                ok, msg = False, str(exc)
            self.after(0, lambda: self._test_done(ok, msg))

        threading.Thread(target=work, daemon=True).start()

    def _test_done(self, ok, msg):
        try:
            self.master.deiconify()
        except Exception:
            pass
        self.deiconify()
        messagebox.showinfo("测试结果", ("成功：" if ok else "失败：") + msg)

    def show(self):
        self.wait_window()
        return self.result


# ------------------------------------------------------------------ 任务编辑器
class PresetDialog(tk.Toplevel):
    """新建任务前先选一个"最接近的样子"，避免面对一堆空框框。"""

    OPTIONS = [
        ("click_app", "打开一个软件，点一下「签到」按钮"),
        ("click_web", "打开一个网页，点一下「签到」按钮"),
        ("msg_app", "打开一个软件，给它发一条消息才算签到"),
        ("blank", "空白任务，我自己一步步配"),
    ]

    def __init__(self, master):
        super().__init__(master)
        self.title("新建任务")
        self.resizable(False, False)
        self.transient(master)
        self.choice = tk.StringVar(value="click_app")
        self.result: str | None = None

        frm = ttk.Frame(self, padding=16)
        frm.pack(fill="both", expand=True)
        ttk.Label(frm, text="你的签到方式更像哪一种？",
                  font=("Microsoft YaHei UI", 11, "bold")).pack(anchor="w", pady=(0, 10))
        for key, text in self.OPTIONS:
            ttk.Radiobutton(frm, text=text, value=key, variable=self.choice).pack(anchor="w", pady=4)
        ttk.Label(frm, text="只是帮你把步骤先摆好，选完还能随便改。",
                  foreground="#888", font=("Microsoft YaHei UI", 9)).pack(anchor="w", pady=(12, 0))

        btns = ttk.Frame(frm)
        btns.pack(pady=(16, 0))
        ttk.Button(btns, text="下一步", width=12, command=self._ok).pack(side="left", padx=6)
        ttk.Button(btns, text="取消", width=12, command=self.destroy).pack(side="left", padx=6)

        self.wait_visibility()
        self.grab_set()
        self.focus_force()

    def _ok(self):
        self.result = self.choice.get()
        self.destroy()

    def show(self):
        self.wait_window()
        return self.result


def make_preset_task(kind: str) -> Task:
    """按预设生成一个"待填"的任务骨架"""
    if kind == "click_web":
        t = Task(name="网页签到", kind="web", target="", browser="system")
    elif kind == "msg_app":
        t = Task(name="发消息签到", kind="app", target="")
    else:
        t = Task(name="软件签到", kind="app", target="")

    if kind == "msg_app":
        t.steps = [
            Step(type="wait", seconds=2.0),
            Step(type="click_image", template="", timeout=30.0,
                 click_after=True),   # 先点开要发消息的会话/联系人
            Step(type="message", template="", text="签到", send_key="enter", timeout=30.0),
        ]
    elif kind == "blank":
        t.steps = []
    else:
        t.steps = [
            Step(type="wait", seconds=2.0),
            Step(type="click_image", template="", timeout=30.0, click_after=True),
        ]
    return t


class TaskDialog(tk.Toplevel):
    """任务编辑器：按「打开什么 → 等它准备好 → 做什么 → 收尾」四步分组。"""

    QUICK = [
        ("click_image", "点按钮（截图）"),
        ("message", "发一条消息"),
        ("wait", "等几秒"),
        ("hotkey", "按组合键"),
        ("press", "按单个键"),
        ("type", "输入文字"),
        ("click_xy", "点固定坐标"),
        ("scroll", "滚滚轮"),
        ("close", "关窗口"),
    ]

    def __init__(self, master, task: Task, title="编辑任务"):
        super().__init__(master)
        self.title(title)
        self.transient(master)
        self.task = task
        self.steps = [Step(**s.__dict__) for s in task.steps]
        self.result: Task | None = None

        self.v = {
            "name": tk.StringVar(value=task.name),
            "kind": tk.StringVar(value=task.kind),
            "target": tk.StringVar(value=task.target),
            "browser": tk.StringVar(value=task.browser),
            "browser_path": tk.StringVar(value=task.browser_path),
            "args": tk.StringVar(value=task.args),
            "launch_wait": tk.StringVar(value=str(task.launch_wait)),
            "window_title": tk.StringVar(value=task.window_title),
            "maximize": tk.BooleanVar(value=task.maximize),
            "close_after": tk.BooleanVar(value=task.close_after),
            "verify_template": tk.StringVar(value=task.verify_template),
            "verify_confidence": tk.StringVar(value=str(task.verify_confidence)),
            "verify_timeout": tk.StringVar(value=str(task.verify_timeout)),
        }

        frm = ttk.Frame(self, padding=12)
        frm.pack(fill="both", expand=True)

        # ---- 名称
        head = ttk.Frame(frm)
        head.pack(fill="x")
        ttk.Label(head, text="任务名称：").pack(side="left")
        ttk.Entry(head, textvariable=self.v["name"], width=26).pack(side="left")
        ttk.Label(head, text="随便起个名字，比如「微信签到」",
                  foreground="#888", font=("Microsoft YaHei UI", 9)).pack(side="left", padx=8)

        # ---- ① 打开什么
        g1 = ttk.LabelFrame(frm, text="① 打开什么", padding=10)
        g1.pack(fill="x", pady=(12, 0))
        ttk.Radiobutton(g1, text="本机软件（.exe）", value="app",
                        variable=self.v["kind"], command=self._refresh).grid(row=0, column=0, sticky="w")
        ttk.Radiobutton(g1, text="网页", value="web",
                        variable=self.v["kind"], command=self._refresh).grid(row=0, column=1, sticky="w")

        self.target_lbl = ttk.Label(g1, text="软件路径：")
        self.target_lbl.grid(row=1, column=0, sticky="w", pady=6)
        ttk.Entry(g1, textvariable=self.v["target"], width=44).grid(row=1, column=1, columnspan=2, sticky="w")
        self.target_btn = ttk.Button(g1, text="浏览…", width=8, command=self._browse_target)
        self.target_btn.grid(row=1, column=3, sticky="w", padx=(6, 0))
        ttk.Label(g1, text="点「浏览」选软件的 exe；网页就填 https:// 开头的地址",
                  foreground="#888", font=("Microsoft YaHei UI", 9)).grid(row=2, column=1, columnspan=3, sticky="w")

        self.browser_frame = ttk.Frame(g1)
        self.browser_frame.grid(row=3, column=0, columnspan=4, sticky="w", pady=(6, 0))
        ttk.Label(self.browser_frame, text="用哪个浏览器：").pack(side="left")
        ttk.Combobox(self.browser_frame, textvariable=self.v["browser"], state="readonly", width=10,
                     values=["system", "chrome", "edge", "custom"]).pack(side="left")
        ttk.Entry(self.browser_frame, textvariable=self.v["browser_path"], width=22).pack(side="left", padx=6)
        ttk.Button(self.browser_frame, text="浏览…", width=8, command=self._browse_browser).pack(side="left")
        ttk.Label(self.browser_frame, text="（选 system 就是用系统默认浏览器）",
                  foreground="#888", font=("Microsoft YaHei UI", 9)).pack(side="left", padx=6)

        ttk.Label(g1, text="启动参数：").grid(row=4, column=0, sticky="w")
        ttk.Entry(g1, textvariable=self.v["args"], width=20).grid(row=4, column=1, sticky="w")
        ttk.Label(g1, text="一般留空就行", foreground="#888",
                  font=("Microsoft YaHei UI", 9)).grid(row=4, column=2, sticky="w")

        # ---- ② 等它准备好
        g2 = ttk.LabelFrame(frm, text="② 等它准备好", padding=10)
        g2.pack(fill="x", pady=(10, 0))
        ttk.Label(g2, text="打开后先等：").grid(row=0, column=0, sticky="w", pady=4)
        ttk.Entry(g2, textvariable=self.v["launch_wait"], width=6).grid(row=0, column=1, sticky="w")
        ttk.Label(g2, text="秒（软件启动慢就填 10~20）",
                  foreground="#888", font=("Microsoft YaHei UI", 9)).grid(row=0, column=2, sticky="w")

        ttk.Label(g2, text="窗口标题里有：").grid(row=1, column=0, sticky="w", pady=4)
        ttk.Entry(g2, textvariable=self.v["window_title"], width=24).grid(row=1, column=1, sticky="w")
        ttk.Label(g2, text="填软件名，如 微信 / Edge，程序会先把这个窗口切到最前面",
                  foreground="#888", font=("Microsoft YaHei UI", 9)).grid(row=1, column=2, sticky="w")

        ttk.Checkbutton(g2, text="顺便最大化窗口", variable=self.v["maximize"]).grid(
            row=2, column=1, columnspan=2, sticky="w", pady=4)

        # ---- ③ 做什么
        g3 = ttk.LabelFrame(frm, text="③ 做什么（从上往下按顺序执行）", padding=10)
        g3.pack(fill="both", expand=True, pady=(10, 0))

        list_frame = ttk.Frame(g3)
        list_frame.pack(fill="both", expand=True)
        self.step_list = tk.Listbox(list_frame, width=70, height=7, font=("Consolas", 10))
        self.step_list.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(list_frame, command=self.step_list.yview)
        sb.pack(side="right", fill="y")
        self.step_list.configure(yscrollcommand=sb.set)
        self.step_list.bind("<Double-Button-1>", lambda e: self._edit_step())

        quick = ttk.Frame(g3)
        quick.pack(fill="x", pady=(8, 0))
        ttk.Label(quick, text="添加：", font=("Microsoft YaHei UI", 9, "bold")).pack(side="left")
        for i, (key, text) in enumerate(self.QUICK):
            ttk.Button(quick, text=text, width=14,
                       command=lambda k=key: self._add_step(k)).pack(side="left", padx=2, pady=2)
            if i == 4:
                # 换行避免挤成一排
                ttk.Frame(quick).pack(side="left")

        ops = ttk.Frame(g3)
        ops.pack(fill="x", pady=6)
        ttk.Button(ops, text="编辑选中", width=10, command=self._edit_step).pack(side="left", padx=2)
        ttk.Button(ops, text="删除", width=8, command=self._del_step).pack(side="left", padx=2)
        ttk.Button(ops, text="上移", width=8, command=lambda: self._move(-1)).pack(side="left", padx=2)
        ttk.Button(ops, text="下移", width=8, command=lambda: self._move(1)).pack(side="left", padx=2)
        ttk.Button(ops, text="测试选中步骤", width=12, command=self._test_step).pack(side="left", padx=2)
        ttk.Label(ops, text="双击也可编辑", foreground="#888",
                  font=("Microsoft YaHei UI", 9)).pack(side="left", padx=8)

        # ---- ④ 收尾
        g4 = ttk.LabelFrame(frm, text="④ 收尾（可选）", padding=10)
        g4.pack(fill="x", pady=(10, 0))
        ttk.Label(g4, text="签成功的样子截图：").grid(row=0, column=0, sticky="w")
        ttk.Entry(g4, textvariable=self.v["verify_template"], width=34).grid(row=0, column=1, sticky="w")
        ttk.Button(g4, text="现在去屏幕截", width=14,
                   command=lambda: Snipper(self, on_done=lambda p: self.v["verify_template"].set(p))
                   ).grid(row=0, column=2, sticky="w", padx=6)
        ttk.Label(g4, text="截一张「已签到」的图，程序找不到它就认为失败了；不想验证可以留空",
                  foreground="#888", font=("Microsoft YaHei UI", 9)).grid(row=1, column=1, columnspan=2, sticky="w")
        ttk.Checkbutton(g4, text="做完把这个窗口关掉", variable=self.v["close_after"]).grid(
            row=2, column=1, sticky="w", pady=4)

        # ---- 按钮
        btns = ttk.Frame(frm)
        btns.pack(pady=(14, 4))
        ttk.Button(btns, text="确定", width=12, command=self._ok).pack(side="left", padx=6)
        ttk.Button(btns, text="取消", width=12, command=self.destroy).pack(side="left", padx=6)
        ttk.Button(btns, text="看不懂？点这里", width=14, command=self._help).pack(side="left", padx=6)

        self._refresh()
        self._reload_steps()
        self.wait_visibility()
        self.grab_set()
        self.focus_force()

    # --- 辅助 -----------------------------------------------------
    def _browse_target(self):
        if self.v["kind"].get() == "app":
            path = filedialog.askopenfilename(parent=self, title="选择要打开的软件",
                                              filetypes=[("可执行程序", "*.exe;*.lnk"), ("所有文件", "*.*")])
            if path:
                self.v["target"].set(path)
        else:
            messagebox.showinfo("提示", "网页类型请在输入框里填网址，以 https:// 开头")

    def _browse_browser(self):
        path = filedialog.askopenfilename(parent=self, title="选择浏览器",
                                          filetypes=[("可执行程序", "*.exe"), ("所有文件", "*.*")])
        if path:
            self.v["browser_path"].set(path)

    def _refresh(self):
        is_app = self.v["kind"].get() == "app"
        self.target_lbl.configure(text="软件路径：" if is_app else "网页地址：")
        if is_app:
            self.browser_frame.grid_remove()
        else:
            self.browser_frame.grid()

    def _reload_steps(self):
        self.step_list.delete(0, "end")
        for i, s in enumerate(self.steps, 1):
            mark = ""
            if s.type in ("click_image", "message") and not s.template:
                mark = "   <<< 还差：去截张图"
            self.step_list.insert("end", f"{i:>2}. [{STEP_LABEL.get(s.type, s.type)}] {s.describe()}{mark}")

    def _sel(self):
        sel = self.step_list.curselection()
        return sel[0] if sel else None

    def _add_step(self, kind="click_image"):
        dlg = StepDialog(self, Step(type=kind), f"添加步骤：{STEP_LABEL.get(kind, kind)}")
        step = dlg.show()
        if step:
            idx = self._sel()
            if idx is None:
                self.steps.append(step)
            else:
                self.steps.insert(idx + 1, step)
            self._reload_steps()

    def _edit_step(self):
        idx = self._sel()
        if idx is None:
            messagebox.showinfo("提示", "先在上面列表里选中一步")
            return
        dlg = StepDialog(self, self.steps[idx], "编辑步骤")
        step = dlg.show()
        if step:
            self.steps[idx] = step
            self._reload_steps()

    def _del_step(self):
        idx = self._sel()
        if idx is None:
            return
        del self.steps[idx]
        self._reload_steps()

    def _move(self, delta):
        idx = self._sel()
        if idx is None:
            return
        new = idx + delta
        if 0 <= new < len(self.steps):
            self.steps[idx], self.steps[new] = self.steps[new], self.steps[idx]
            self._reload_steps()
            self.step_list.selection_set(new)

    def _test_step(self):
        idx = self._sel()
        if idx is None:
            messagebox.showinfo("提示", "先在上面列表里选中一步")
            return
        dlg = StepDialog(self, self.steps[idx], "编辑步骤")
        dlg._test()
        dlg.destroy()

    def _help(self):
        messagebox.showinfo(
            "怎么填？",
            "一句话：告诉程序「开什么 → 等多久 → 点哪儿 / 发什么 → 算不算成功」。\n\n"
            "① 打开什么：软件就点「浏览」选 exe；网页就填网址。\n"
            "② 等它准备好：软件打开要时间，先等 8 秒（慢的就填 15~20）。\n"
            "   窗口标题填软件名（比如 微信、钉钉、Edge），程序会把它切到最前面再操作。\n"
            "③ 做什么：点「点按钮（截图）」→ 点「现在去屏幕截」→ 用鼠标把签到按钮框起来。\n"
            "   要是得发句话才算签到，就点「发一条消息」：截输入框 → 填内容 → 发送键填 enter。\n"
            "④ 收尾：想确认真的签上了，就截一张「已签到」的图放这儿。\n\n"
            "配完先点「测试选中步骤」或主界面的「测试运行选中」，确认能点上再开定时。",
            parent=self)

    def _ok(self):
        name = self.v["name"].get().strip()
        if not name:
            messagebox.showwarning("还差一步", "先给任务起个名字")
            return
        if not self.v["target"].get().strip():
            messagebox.showwarning("还差一步", "① 里要填软件路径或网址")
            return
        need_shot = [s for s in self.steps if s.type in ("click_image", "message") and not s.template]
        if need_shot:
            if not messagebox.askyesno(
                    "有步骤还没截图",
                    f"有 {len(need_shot)} 个步骤还没截按钮/输入框的图，运行时会失败。\n仍要保存吗？"):
                return

        def f(key, default):
            try:
                return float(self.v[key].get())
            except Exception:
                return default

        self.result = Task(
            id=self.task.id,
            name=name,
            enabled=self.task.enabled,
            kind=self.v["kind"].get(),
            target=self.v["target"].get().strip(),
            browser=self.v["browser"].get(),
            browser_path=self.v["browser_path"].get().strip(),
            args=self.v["args"].get().strip(),
            launch_wait=max(0.0, f("launch_wait", 8.0)),
            window_title=self.v["window_title"].get().strip(),
            maximize=self.v["maximize"].get(),
            close_after=self.v["close_after"].get(),
            steps=self.steps,
            verify_template=self.v["verify_template"].get().strip(),
            verify_confidence=min(0.99, max(0.5, f("verify_confidence", 0.85))),
            verify_timeout=max(1.0, f("verify_timeout", 15.0)),
        )
        self.destroy()

    def show(self):
        self.wait_window()
        return self.result


# ------------------------------------------------------------------ 倒计时关机窗
class CountdownDialog(tk.Toplevel):
    def __init__(self, master, mode: str, delay: int, on_finish, log=None):
        super().__init__(master)
        self.title("即将关机")
        self.resizable(False, False)
        self.mode = mode
        self.total = max(1, int(delay))
        self.on_finish = on_finish
        self.log = log or (lambda m, l="info": None)
        self.cancelled = False
        # 用单调时钟算截止时间：系统卡顿/进入待机会打乱 after 的节拍，按剩余秒数反推更稳
        self.deadline = time.monotonic() + self.total
        self.attributes("-topmost", True)

        label_text = {
            "shutdown": "关机", "sleep": "睡眠", "hibernate": "休眠",
        }.get(mode, "关机")

        frm = ttk.Frame(self, padding=20)
        frm.pack(fill="both", expand=True)
        ttk.Label(frm, text="签到任务已全部执行完成", font=("Microsoft YaHei UI", 11)).pack()
        self.lbl = ttk.Label(frm, text="", font=("Microsoft YaHei UI", 20, "bold"), foreground="#d9534f")
        self.lbl.pack(pady=14)
        ttk.Label(frm, text=f"即将{label_text}，点击「取消」可中止").pack()

        btns = ttk.Frame(frm)
        btns.pack(pady=(16, 0))
        ttk.Button(btns, text=f"立即{label_text}", command=self._now, width=14).pack(side="left", padx=8)
        ttk.Button(btns, text="取消", command=self._cancel, width=14).pack(side="left", padx=8)

        self.protocol("WM_DELETE_WINDOW", self._cancel)
        try:
            self.lift()
            self.focus_force()
        except Exception:
            pass
        self._tick()

    def _tick(self):
        if self.cancelled:
            return
        left = max(0, int(round(self.deadline - time.monotonic())))
        self.lbl.configure(text=f"{left} 秒")
        if left <= 0:
            self.cancelled = True
            self.log(f"[关机] 倒计时结束，开始执行 {self.mode}", "warn")
            self.destroy()
            self.on_finish("倒计时结束")
            return
        if left in (30, 10):
            self.log(f"[关机] 还剩 {left} 秒", "info")
        self.after(250, self._tick)

    def _now(self):
        if self.cancelled:
            return
        self.cancelled = True
        self.destroy()
        self.on_finish("手动点击立即执行")

    def _cancel(self):
        if self.cancelled:
            return
        self.cancelled = True
        power.cancel_shutdown()
        self.destroy()
        self.log("[关机] 已取消，本次不关机", "warn")


# ------------------------------------------------------------------ 主界面
class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.cfg = load_config()
        self.q: queue.Queue = queue.Queue()          # 日志行
        self.event_q: queue.Queue = queue.Queue()    # 跨线程事件（执行结束等）
        self.runner: Runner | None = None
        self.scheduler: Scheduler | None = None
        self._user_stopped = False
        # 手动「立即执行全部」是否在完成后执行关机动作（主界面可勾选，会记住）
        self.var_run_power = tk.BooleanVar(value=bool(getattr(self.cfg.settings, "manual_run_power", False)))

        root.title("自动签到助手 v1.0")
        root.geometry("1000x680")
        root.minsize(900, 600)

        self._build_ui()
        self._reload_tasks()
        self._pump()

        self.scheduler = Scheduler(lambda: self.cfg,
                                   self._make_runner,
                                   log=self.log,
                                   busy_check=self._busy)
        # 注意：这里不能直接调 self.root.after()——scheduler 在工作线程里，
        # tkinter 不是线程安全的，跨线程调 after 可能直接抛异常并被 pythonw 吞掉，
        # 表现就是"任务跑完了但没关机"。统一走队列，由主线程的 _pump 消费。
        self.scheduler.on_finish = lambda results: self.event_q.put(("run_done", (results, False)))
        self.scheduler.start()

        self.log("程序已启动。建议先添加任务并「测试运行」验证，再开启每日定时。", "ok")
        st = self.cfg.settings
        self.log(f"当前设定：每日 {st.daily_time} 自动执行 → {st.shutdown_mode}（延迟 {st.shutdown_delay}s）", "info")
        # 开机自启自检：设置里要求自启，但启动入口不见了（被清理/被禁用/目录被改），自动补回来
        if st.start_with_windows:
            fixed, info = autostart.repair_if_needed()
            enabled, method = autostart.status()
            if fixed:
                self.log(f"开机自启入口丢失，已自动重新注册（{method}）", "warn")
            elif enabled:
                self.log(f"开机自启：已开启（{method}）", "info")
            else:
                self.log(f"开机自启：异常（{info}），请到「高级设置」重新开启", "error")
        else:
            self.log("开机自启：未开启（可在「高级设置」里打开）", "info")

    # ------------------------------------------------------------ UI
    def _build_ui(self):
        top = ttk.Frame(self.root, padding=(12, 10))
        top.pack(fill="x")

        self.var_auto = tk.BooleanVar(value=self.cfg.settings.auto_enabled)
        self.var_time = tk.StringVar(value=self.cfg.settings.daily_time)

        ttk.Checkbutton(top, text="启用每日定时任务", variable=self.var_auto,
                        command=self._on_toggle_auto).pack(side="left")
        ttk.Label(top, text="  执行时间：").pack(side="left")
        self.time_entry = ttk.Entry(top, textvariable=self.var_time, width=8)
        self.time_entry.pack(side="left")
        ttk.Label(top, text="（24 小时制 HH:MM）").pack(side="left")
        ttk.Button(top, text="保存设置", command=self._save_settings, width=10).pack(side="left", padx=(14, 0))
        ttk.Button(top, text="高级设置", command=self._open_settings, width=10).pack(side="left", padx=6)
        ttk.Button(top, text="打开模板目录", command=self._open_templates, width=12).pack(side="left", padx=6)

        self.status_lbl = ttk.Label(top, text="", foreground="#0a7d33")
        self.status_lbl.pack(side="right")

        mid = ttk.Frame(self.root, padding=(12, 0))
        mid.pack(fill="both", expand=True)

        cols = ("enabled", "name", "kind", "target", "steps")
        self.tree = ttk.Treeview(mid, columns=cols, show="headings", height=12)
        for c, w, txt in zip(cols, (60, 170, 60, 360, 70), ("启用", "任务名称", "类型", "目标", "步骤")):
            self.tree.heading(c, text=txt)
            self.tree.column(c, width=w, anchor="w")
        self.tree.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(mid, command=self.tree.yview)
        sb.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.bind("<Double-1>", lambda e: self._edit_task())

        ops = ttk.Frame(self.root, padding=(12, 8))
        ops.pack(fill="x")

        ops1 = ttk.Frame(ops)          # 第一行：任务管理
        ops1.pack(fill="x")
        ttk.Button(ops1, text="＋ 新增任务", command=self._add_task).pack(side="left", padx=3)
        ttk.Button(ops1, text="编辑", width=8, command=self._edit_task).pack(side="left", padx=3)
        ttk.Button(ops1, text="删除", width=8, command=self._del_task).pack(side="left", padx=3)
        ttk.Button(ops1, text="↑", width=4, command=lambda: self._move_task(-1)).pack(side="left", padx=3)
        ttk.Button(ops1, text="↓", width=4, command=lambda: self._move_task(1)).pack(side="left", padx=3)
        ttk.Button(ops1, text="启用/禁用", width=10, command=self._toggle_task).pack(side="left", padx=3)

        ops2 = ttk.Frame(ops)          # 第二行：运行
        ops2.pack(fill="x", pady=(6, 0))
        ttk.Button(ops2, text="▶ 测试运行选中", command=self._test_task).pack(side="left", padx=3)
        ttk.Button(ops2, text="▶▶ 立即执行全部",
                   command=lambda: self._run_all(skip_power=not self.var_run_power.get())
                   ).pack(side="left", padx=3)
        ttk.Checkbutton(ops2, text="全部跑完后关机", variable=self.var_run_power,
                        command=self._on_run_power_toggle).pack(side="left", padx=(6, 3))
        ttk.Button(ops2, text="■ 停止", command=self._stop).pack(side="left", padx=3)
        ttk.Separator(ops2, orient="vertical").pack(side="left", fill="y", padx=8)
        ttk.Button(ops2, text="屏幕截图取模板",
                   command=lambda: Snipper(self.root, on_done=self._on_snip)).pack(side="left", padx=3)

        logf = ttk.LabelFrame(self.root, text="运行日志", padding=6)
        logf.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self.log_text = tk.Text(logf, height=12, wrap="word", font=("Consolas", 10))
        self.log_text.pack(side="left", fill="both", expand=True)
        lsb = ttk.Scrollbar(logf, command=self.log_text.yview)
        lsb.pack(side="right", fill="y")
        self.log_text.configure(yscrollcommand=lsb.set, state="disabled")
        for tag, color in (("info", "#333333"), ("ok", "#0a7d33"), ("warn", "#b8860b"),
                           ("error", "#c0392b"), ("debug", "#888888")):
            self.log_text.tag_configure(tag, foreground=color)

    # ------------------------------------------------------------ 日志
    def log(self, msg: str, level: str = "info"):
        ts = dt.datetime.now().strftime("%H:%M:%S")
        self.q.put((f"[{ts}] {msg}", level))
        try:
            with _LOG_LOCK:
                with open(os.path.join(LOG_DIR, f"{dt.datetime.now():%Y-%m-%d}.log"),
                          "a", encoding="utf-8") as f:
                    f.write(f"[{dt.datetime.now():%Y-%m-%d %H:%M:%S}][{level}] {msg}\n")
        except Exception:
            pass

    def _pump(self):
        try:
            while True:
                msg, level = self.q.get_nowait()
                self.log_text.configure(state="normal")
                self.log_text.insert("end", msg + "\n", level)
                self.log_text.see("end")
                self.log_text.configure(state="disabled")
        except queue.Empty:
            pass

        # 跨线程事件（执行结束 → 关机流程）统一在主线程处理
        try:
            while True:
                kind, payload = self.event_q.get_nowait()
                if kind == "run_done":
                    results, skip_power = payload
                    self._after_run(results, skip_power)
        except queue.Empty:
            pass

        self.root.after(120, self._pump)

    # ------------------------------------------------------------ 任务列表
    def _reload_tasks(self):
        self.tree.delete(*self.tree.get_children())
        for t in self.cfg.tasks:
            self.tree.insert("", "end", iid=t.id, values=(
                "✔" if t.enabled else "✘", t.name, "程序" if t.kind == "app" else "网页",
                t.describe_target(), len(t.steps)))
        total = len(self.cfg.tasks)
        on = sum(1 for t in self.cfg.tasks if t.enabled)
        self.status_lbl.configure(text=f"共 {total} 个任务（启用 {on}）")

    def _sel_task(self) -> Task | None:
        sel = self.tree.selection()
        if not sel:
            return None
        tid = sel[0]
        for t in self.cfg.tasks:
            if t.id == tid:
                return t
        return None

    def _add_task(self):
        preset = PresetDialog(self.root).show()
        if not preset:
            return
        base = make_preset_task(preset)
        base.name = f"{base.name}{len(self.cfg.tasks)+1}"
        dlg = TaskDialog(self.root, base, "新增任务")
        task = dlg.show()
        if task:
            self.cfg.tasks.append(task)
            save_config(self.cfg)
            self._reload_tasks()
            self.log("新任务已添加，记得先「测试运行选中」验证一遍", "ok")

    def _edit_task(self):
        t = self._sel_task()
        if not t:
            messagebox.showinfo("提示", "请先选中一个任务")
            return
        dlg = TaskDialog(self.root, t, "编辑任务")
        res = dlg.show()
        if res:
            idx = self.cfg.tasks.index(t)
            res.enabled = t.enabled
            self.cfg.tasks[idx] = res
            save_config(self.cfg)
            self._reload_tasks()

    def _del_task(self):
        t = self._sel_task()
        if not t:
            return
        if messagebox.askyesno("确认", f"确定删除任务「{t.name}」？"):
            self.cfg.tasks.remove(t)
            save_config(self.cfg)
            self._reload_tasks()

    def _move_task(self, delta):
        t = self._sel_task()
        if not t:
            return
        i = self.cfg.tasks.index(t)
        j = i + delta
        if 0 <= j < len(self.cfg.tasks):
            self.cfg.tasks[i], self.cfg.tasks[j] = self.cfg.tasks[j], self.cfg.tasks[i]
            save_config(self.cfg)
            self._reload_tasks()
            self.tree.selection_set(t.id)

    def _toggle_task(self):
        t = self._sel_task()
        if not t:
            return
        t.enabled = not t.enabled
        save_config(self.cfg)
        self._reload_tasks()

    # ------------------------------------------------------------ 设置
    def _save_settings(self, silent=False):
        t = self.var_time.get().strip()
        try:
            dt.datetime.strptime(t, "%H:%M")
        except Exception:
            messagebox.showerror("格式错误", "时间格式应为 HH:MM，例如 08:30")
            return False
        self.cfg.settings.daily_time = t
        self.cfg.settings.auto_enabled = self.var_auto.get()
        save_config(self.cfg)
        if not silent:
            self.log(f"设置已保存：每日 {t} 执行（{'开启' if self.var_auto.get() else '关闭'}）", "ok")
        return True

    def _on_toggle_auto(self):
        self._save_settings(silent=True)
        self.log("每日定时任务已" + ("开启" if self.var_auto.get() else "关闭"), "info")

    def _open_settings(self):
        st = self.cfg.settings
        dlg = tk.Toplevel(self.root)
        dlg.title("高级设置")
        dlg.resizable(False, False)
        dlg.transient(self.root)
        dlg.grab_set()

        frm = ttk.Frame(dlg, padding=14)
        frm.pack(fill="both", expand=True)

        v_mode = tk.StringVar(value=st.shutdown_mode)
        v_delay = tk.StringVar(value=str(st.shutdown_delay))
        v_ask = tk.BooleanVar(value=st.ask_before_power)
        v_only_ok = tk.BooleanVar(value=st.power_only_if_all_ok)
        v_retry = tk.BooleanVar(value=st.retry_failed)
        v_catch = tk.BooleanVar(value=st.catch_up)
        v_catch_min = tk.StringVar(value=str(getattr(st, "catch_up_minutes", 60)))
        v_manual_power = tk.BooleanVar(value=getattr(st, "manual_run_power", False))
        v_shot = tk.BooleanVar(value=st.fail_screenshot)
        v_auto_start = tk.BooleanVar(value=autostart.is_enabled())

        r = 0
        ttk.Label(frm, text="完成后动作：", font=("Microsoft YaHei UI", 10, "bold")).grid(row=r, column=0, sticky="w", pady=4)
        cb = ttk.Combobox(frm, textvariable=v_mode, state="readonly", width=14,
                          values=["shutdown", "sleep", "hibernate", "none"])
        cb.grid(row=r, column=1, sticky="w", pady=4)
        ttk.Label(frm, text="shutdown=关机  sleep=睡眠  hibernate=休眠  none=不做").grid(row=r, column=2, sticky="w")
        r += 1

        ttk.Label(frm, text="延迟秒数：").grid(row=r, column=0, sticky="w", pady=4)
        ttk.Entry(frm, textvariable=v_delay, width=10).grid(row=r, column=1, sticky="w")
        r += 1
        ttk.Checkbutton(frm, text="关机前弹出倒计时窗口（可取消，强烈建议开启）",
                        variable=v_ask).grid(row=r, column=0, columnspan=3, sticky="w", pady=4)
        r += 1
        ttk.Checkbutton(frm, text="仅当全部任务成功时才执行关机",
                        variable=v_only_ok).grid(row=r, column=0, columnspan=3, sticky="w", pady=4)
        r += 1

        ttk.Separator(frm).grid(row=r, column=0, columnspan=3, sticky="ew", pady=10)
        r += 1
        ttk.Label(frm, text="执行策略：", font=("Microsoft YaHei UI", 10, "bold")).grid(row=r, column=0, sticky="w", pady=4)
        r += 1
        ttk.Checkbutton(frm, text="任务失败自动重试 1 次", variable=v_retry).grid(row=r, column=0, columnspan=3, sticky="w", pady=3)
        r += 1
        ttk.Checkbutton(frm, text="错过时间补跑（开机晚了当天仍会执行一次）",
                        variable=v_catch).grid(row=r, column=0, columnspan=3, sticky="w", pady=3)
        r += 1
        fr = ttk.Frame(frm)
        fr.grid(row=r, column=0, columnspan=3, sticky="w", pady=3)
        ttk.Label(fr, text="    补跑时限：").pack(side="left")
        ttk.Entry(fr, textvariable=v_catch_min, width=6).pack(side="left")
        ttk.Label(fr, text="分钟内才补跑（超时太久就不再自动执行，防止误触发关机）").pack(side="left")
        r += 1
        ttk.Checkbutton(frm, text="失败时自动保存屏幕截图", variable=v_shot).grid(row=r, column=0, columnspan=3, sticky="w", pady=3)
        r += 1
        ttk.Checkbutton(frm, text="手动「立即执行全部」完成后也执行上面的动作（默认关，防误关）",
                        variable=v_manual_power).grid(row=r, column=0, columnspan=3, sticky="w", pady=3)
        r += 1
        ttk.Checkbutton(frm, text="开机自启（后台静默运行）", variable=v_auto_start).grid(row=r, column=0, columnspan=3, sticky="w", pady=3)
        r += 1
        st_frame = ttk.Frame(frm)
        st_frame.grid(row=r, column=0, columnspan=3, sticky="w")
        st_lbl = ttk.Label(st_frame, text="")
        st_lbl.pack(side="left", padx=(24, 8))
        ttk.Button(st_frame, text="重新注册自启", width=12, command=lambda: do_register()).pack(side="left")
        ttk.Label(st_frame, text="（自启没生效时点它）", foreground="#888",
                  font=("Microsoft YaHei UI", 9)).pack(side="left", padx=6)
        r += 1

        def refresh_status():
            enabled, method = autostart.status()
            st_lbl.configure(text=f"当前状态：{'已开启' if enabled else '未开启'} — {method}",
                             foreground="#0a7d33" if enabled else "#b8860b")

        def do_register():
            ok, method, msg = autostart.enable()
            if ok:
                st.start_with_windows = True
                v_auto_start.set(True)
                save_config(self.cfg)
                self.log(f"开机自启已注册：{method}", "ok")
            else:
                self.log(f"开机自启注册失败：{msg}", "error")
                messagebox.showerror("注册失败", msg)
            refresh_status()

        refresh_status()

        def on_ok():
            st.shutdown_mode = v_mode.get()
            try:
                st.shutdown_delay = max(0, int(v_delay.get()))
            except Exception:
                st.shutdown_delay = 60
            st.ask_before_power = v_ask.get()
            st.power_only_if_all_ok = v_only_ok.get()
            st.retry_failed = v_retry.get()
            st.catch_up = v_catch.get()
            try:
                st.catch_up_minutes = max(1, int(v_catch_min.get()))
            except Exception:
                st.catch_up_minutes = 60
            st.fail_screenshot = v_shot.get()
            st.manual_run_power = v_manual_power.get()
            try:
                self.var_run_power.set(v_manual_power.get())  # 与主界面勾选框保持一致
            except Exception:
                pass
            st.start_with_windows = v_auto_start.get()
            save_config(self.cfg)
            if v_auto_start.get():
                ok, method, msg = autostart.enable()
                self.log(f"开机自启：{'已开启（' + method + '）' if ok else '注册失败 — ' + msg}",
                         "ok" if ok else "error")
            else:
                autostart.disable()
                self.log("开机自启：已关闭", "info")
            self.log("高级设置已保存", "ok")
            dlg.destroy()

        btns = ttk.Frame(frm)
        btns.grid(row=r, column=0, columnspan=3, pady=(14, 0))
        ttk.Button(btns, text="确定", width=12, command=on_ok).pack(side="left", padx=8)
        ttk.Button(btns, text="取消", width=12, command=dlg.destroy).pack(side="left", padx=8)

    def _open_templates(self):
        os.startfile(TEMPLATE_DIR)

    def _on_snip(self, path):
        self.log(f"已保存模板：{path}", "ok")

    # ------------------------------------------------------------ 执行
    def _busy(self) -> bool:
        return bool(self.runner and self.runner.is_running)

    def _make_runner(self) -> Runner:
        """统一记录当前 runner：定时任务也记在这里，_busy() 才能拦住重复执行。"""
        self._user_stopped = False
        self.runner = Runner(self.cfg, log=self.log)
        return self.runner

    def _run_all(self, tasks=None, skip_power: bool = True):
        """skip_power=True 表示手动/测试运行，不执行关机。"""
        if self._busy():
            messagebox.showinfo("提示", "任务正在执行中")
            return
        if not self._save_settings(silent=True):
            return
        self.root.iconify()

        def work():
            results: list = []
            try:
                runner = self._make_runner()
                results = runner.run_all(only=tasks)
            except Exception as exc:  # noqa
                self.log(f"执行异常：{exc}", "error")
            finally:
                # 同样不能跨线程调 root.after，走事件队列
                self.event_q.put(("run_done", (results, skip_power)))

        threading.Thread(target=work, daemon=True).start()

    def _on_run_power_toggle(self):
        val = self.var_run_power.get()
        self.cfg.settings.manual_run_power = val
        save_config(self.cfg)
        mode = self.cfg.settings.shutdown_mode
        if not val:
            self.log("已关闭：手动执行完不会关机", "info")
        elif mode == "none":
            self.log("已勾选「完成后关机」，但当前完成动作是「不动作」——请到「高级设置」把动作改成 shutdown", "warn")
        else:
            self.log(f"已开启：手动执行完全部任务后，将执行「{mode}」动作"
                     f"（{self.cfg.settings.shutdown_delay} 秒倒计时，可取消）", "warn")

    def _test_task(self):
        t = self._sel_task()
        if not t:
            messagebox.showinfo("提示", "请先选中一个任务")
            return
        self.log(f"=== 测试运行：{t.name}（单任务测试，无论是否勾选「完成后关机」都不会关机）===", "info")
        self._run_all(tasks=[t], skip_power=True)

    def _stop(self):
        if self.runner:
            self._user_stopped = True
            self.runner.stop()

    def _after_run(self, results, skip_power: bool):
        try:
            self.root.deiconify()
        except Exception:
            pass

        total = len(results)
        ok_n = sum(1 for r in results if r.get("ok"))
        self.log(f"本轮结果：成功 {ok_n}/{total}", "ok" if total and ok_n == total else "warn")

        st = self.cfg.settings
        # 用户中途点了「停止」：说明他不想继续了，更不能顺手把电脑关掉
        if getattr(self, "_user_stopped", False):
            self.log("本轮被手动停止，不执行关机", "warn")
            return
        # 手动执行默认不关机（防误关），除非用户在高级设置里显式打开
        if skip_power and not getattr(st, "manual_run_power", False):
            self.log("手动执行结束，未勾选「完成后关机」，本次不关机", "warn")
            return
        self._handle_power(results)

    def _handle_power(self, results):
        st = self.cfg.settings
        mode = st.shutdown_mode
        self.log(f"[关机判断] 动作={mode} 延迟={st.shutdown_delay}s "
                 f"仅全部成功才关机={st.power_only_if_all_ok} 任务数={len(results)}", "info")

        if mode == "none":
            self.log("完成后动作设为「不动作」，本轮不执行关机", "warn")
            return
        if not results:
            self.log("本轮没有执行任何任务（列表为空或全部禁用），跳过关机", "warn")
            return
        if st.power_only_if_all_ok and not all(r.get("ok") for r in results):
            failed = [str(r.get("task")) for r in results if not r.get("ok")]
            self.log(f"有任务失败（{', '.join(failed)}），按设置不执行关机", "warn")
            return

        def do(why: str = ""):
            self.log(f"[关机] 开始执行 {mode} {why}".strip(), "warn")
            ok, msg = power.perform(mode)
            if ok:
                self.log(f"[关机] 成功：{msg}", "ok")
            else:
                self.log(f"[关机] 失败：{msg}（详见 logs/power.log）", "error")
                try:
                    messagebox.showerror(
                        "关机失败",
                        f"{msg}\n\n常见原因：\n"
                        f"· 其他程序（文档/播放器）阻止关机\n"
                        f"· 系统策略或安全软件禁止关机\n"
                        f"· 当前会话权限不足\n\n详细记录见 logs\\power.log",
                    )
                except Exception:
                    pass

        if st.ask_before_power:
            try:
                self.root.deiconify()
                self.root.lift()
            except Exception:
                pass
            self.log(f"[关机] 弹出 {st.shutdown_delay} 秒倒计时窗口（期间可取消）", "warn")
            CountdownDialog(self.root, mode, st.shutdown_delay, do, self.log)
        else:
            self.log(f"[关机] {st.shutdown_delay} 秒后执行 {mode}（不弹倒计时窗口）", "warn")
            threading.Timer(max(0, st.shutdown_delay), do).start()

    # ------------------------------------------------------------ 关闭
    def on_close(self):
        if self._busy():
            if not messagebox.askyesno("确认", "任务正在执行，确定退出？"):
                return
            self._stop()
        if self.var_auto.get():
            if messagebox.askyesno("退出", "定时任务已开启，退出后到点不会再自动执行。\n确定退出程序吗？"):
                self.shutdown_app()
        else:
            self.shutdown_app()

    def shutdown_app(self):
        if self.scheduler:
            self.scheduler.stop()
        self.root.destroy()


def main():
    root = tk.Tk()
    try:
        from ctypes import windll
        windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    style = ttk.Style()
    try:
        style.theme_use("clam")
    except Exception:
        pass
    app = App(root)
    root.protocol("WM_DELETE_WINDOW", app.on_close)
    root.mainloop()


if __name__ == "__main__":
    main()
