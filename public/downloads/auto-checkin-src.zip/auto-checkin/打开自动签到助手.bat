@echo off
cd /d "%~dp0"
set "SYSPY=C:/Users/13418/AppData/Local/Programs/Python/Python313/python.exe"

if exist "venv-gui\Scripts\pythonw.exe" goto RUN

echo [1/2] Creating virtual environment: venv-gui ...
if exist "%SYSPY%" (
    "%SYSPY%" -m venv venv-gui
) else (
    python -m venv venv-gui
)
if not exist "venv-gui\Scripts\pythonw.exe" (
    echo [ERROR] Cannot create venv. Please install Python 3.9+ first.
    pause
    exit /b 1
)

echo [2/2] Installing dependencies, first run takes 1-3 minutes ...
"venv-gui\Scripts\python.exe" -m pip install -r requirements.txt

:RUN
start "" "venv-gui\Scripts\pythonw.exe" main.py
