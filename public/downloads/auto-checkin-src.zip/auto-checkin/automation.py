# -*- coding: utf-8 -*-
"""屏幕找图、窗口控制与鼠标键盘模拟（Windows）。"""
from __future__ import annotations

import ctypes
import os
import time
from ctypes import wintypes
from typing import List, Optional, Tuple

import cv2
import numpy as np
import pyautogui
from PIL import Image, ImageGrab

pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.15

# ------------------------------------------------------------------ Win32
user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

SW_RESTORE = 9
SW_MAXIMIZE = 3
SW_SHOWNORMAL = 1
WM_CLOSE = 0x0010

EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)

SM_XVIRTUALSCREEN = 76
SM_YVIRTUALSCREEN = 77
SM_CXVIRTUALSCREEN = 78
SM_CYVIRTUALSCREEN = 79


def _get_system_metrics(index: int) -> int:
    return int(user32.GetSystemMetrics(index))


def virtual_screen() -> Tuple[int, int, int, int]:
    """返回虚拟屏幕（多显示器合并）的逻辑坐标：x, y, w, h"""
    return (
        _get_system_metrics(SM_XVIRTUALSCREEN),
        _get_system_metrics(SM_YVIRTUALSCREEN),
        _get_system_metrics(SM_CXVIRTUALSCREEN),
        _get_system_metrics(SM_CYVIRTUALSCREEN),
    )


def _enum_windows() -> List[int]:
    handles: List[int] = []

    def _cb(hwnd, lparam):
        if user32.IsWindowVisible(hwnd):
            handles.append(int(hwnd))
        return True

    user32.EnumWindows(EnumWindowsProc(_cb), 0)
    return handles


def _window_title(hwnd: int) -> str:
    length = user32.GetWindowTextLengthW(hwnd)
    if length == 0:
        return ""
    buf = ctypes.create_unicode_buffer(length + 1)
    user32.GetWindowTextW(hwnd, buf, length + 1)
    return buf.value


def find_windows(keyword: str) -> List[Tuple[int, str]]:
    """按标题关键词（不区分大小写）查找可见窗口"""
    if not keyword:
        return []
    kw = keyword.lower()
    out = []
    for h in _enum_windows():
        title = _window_title(h)
        if kw in title.lower():
            out.append((h, title))
    return out


def _force_foreground(hwnd: int) -> bool:
    """把窗口强行切到前台。

    Windows 有"前台锁"：后台进程调 SetForegroundWindow 常常只是任务栏闪一下，窗口并不上来，
    后面的找图/点击就会点到被挡住的界面上。这里用 AttachThreadInput 绕过。
    """
    try:
        if user32.GetForegroundWindow() == hwnd:
            return True
        fg = user32.GetForegroundWindow()
        cur_tid = kernel32.GetCurrentThreadId()
        fg_tid = user32.GetWindowThreadProcessId(fg, None) if fg else 0
        attached = False
        if fg_tid and fg_tid != cur_tid:
            attached = bool(user32.AttachThreadInput(fg_tid, cur_tid, True))
        user32.BringWindowToTop(wintypes.HWND(hwnd))
        user32.SetForegroundWindow(wintypes.HWND(hwnd))
        if attached:
            user32.AttachThreadInput(fg_tid, cur_tid, False)
        time.sleep(0.25)
        return user32.GetForegroundWindow() == hwnd
    except Exception:
        return False


def focus_window(keyword: str, maximize: bool = False, timeout: float = 20.0) -> Optional[str]:
    """把包含关键词的窗口置前；返回命中的窗口标题"""
    if not keyword:
        return None
    deadline = time.time() + timeout
    hit = None
    while time.time() < deadline:
        found = find_windows(keyword)
        if found:
            hwnd, title = found[0]
            hit = title
            try:
                user32.ShowWindow(wintypes.HWND(hwnd), SW_RESTORE)
                time.sleep(0.2)
                for _ in range(3):
                    if _force_foreground(hwnd):
                        break
                    time.sleep(0.3)
                if maximize:
                    user32.ShowWindow(wintypes.HWND(hwnd), SW_MAXIMIZE)
                time.sleep(0.5)
            except Exception:
                pass
            return title
        time.sleep(0.5)
    return hit


def close_window(keyword: str) -> bool:
    found = find_windows(keyword)
    if not found:
        return False
    for hwnd, _ in found[:3]:
        try:
            user32.PostMessageW(wintypes.HWND(hwnd), WM_CLOSE, 0, 0)
        except Exception:
            pass
    return True


def window_rect(keyword: str) -> Optional[Tuple[int, int, int, int]]:
    """返回窗口的逻辑坐标 (left, top, right, bottom)"""
    found = find_windows(keyword)
    if not found:
        return None
    rect = wintypes.RECT()
    if user32.GetWindowRect(wintypes.HWND(found[0][0]), ctypes.byref(rect)):
        return (rect.left, rect.top, rect.right, rect.bottom)
    return None


# ------------------------------------------------------------------ 截图
def screenshot(save_path: Optional[str] = None) -> Image.Image:
    img = ImageGrab.grab(all_screens=True)
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        img.save(save_path)
    return img


class ScreenMapper:
    """把「截图像素坐标」换算成「鼠标逻辑坐标」，自动处理 DPI 缩放与多屏。"""

    def __init__(self, image: Image.Image):
        self.img_w, self.img_h = image.size
        vx, vy, vw, vh = virtual_screen()
        self.origin_x, self.origin_y = vx, vy
        self.vw, self.vh = max(vw, 1), max(vh, 1)
        self.scale_x = self.img_w / float(self.vw)
        self.scale_y = self.img_h / float(self.vh)

    def to_screen(self, px: float, py: float) -> Tuple[int, int]:
        return (
            int(round(self.origin_x + px / self.scale_x)),
            int(round(self.origin_y + py / self.scale_y)),
        )

    def to_image(self, x: float, y: float) -> Tuple[int, int]:
        """逻辑屏幕坐标 -> 截图像素坐标"""
        return (
            int(round((x - self.origin_x) * self.scale_x)),
            int(round((y - self.origin_y) * self.scale_y)),
        )


# ------------------------------------------------------------------ 找图
DEFAULT_SCALES = (0.6, 0.7, 0.8, 0.9, 0.95, 1.0, 1.05, 1.1, 1.25, 1.5, 2.0)


def _load_template(path: str) -> Optional[np.ndarray]:
    if not path or not os.path.exists(path):
        return None
    # imread 不支持中文路径时改用 numpy + imdecode
    img = cv2.imread(path, cv2.IMREAD_COLOR)
    if img is None:
        try:
            data = np.fromfile(path, dtype=np.uint8)
            img = cv2.imdecode(data, cv2.IMREAD_COLOR)
        except Exception:
            return None
    return img


def locate(
    template_path: str,
    confidence: float = 0.85,
    scales=DEFAULT_SCALES,
    region: Optional[Tuple[int, int, int, int]] = None,
) -> Tuple[Optional[Tuple[int, int]], float]:
    """在屏幕上多尺度查找模板。

    返回 (屏幕逻辑坐标 or None, 最佳匹配分数)。
    """
    tpl = _load_template(template_path)
    if tpl is None:
        raise FileNotFoundError(f"模板文件不存在或无法读取：{template_path}")

    # 纯色/单调模板会到处"完美匹配"，直接拒绝
    gray_tpl = cv2.cvtColor(tpl, cv2.COLOR_BGR2GRAY)
    if float(np.std(gray_tpl)) < 5.0:
        raise ValueError(
            "模板图片内容过于单一（几乎是纯色），会到处误匹配。"
            "请重新截取包含按钮文字或边框的区域。"
        )

    img = screenshot()
    mapper = ScreenMapper(img)
    hay = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)

    if region:
        x0, y0, x1, y1 = region
        x0, y0 = max(0, int(x0)), max(0, int(y0))
        x1, y1 = min(hay.shape[1], int(x1)), min(hay.shape[0], int(y1))
        if x1 > x0 and y1 > y0:
            roi = hay[y0:y1, x0:x1]
        else:
            roi = hay
            x0 = y0 = 0
    else:
        roi = hay
        x0 = y0 = 0

    best_val, best_box = -1.0, None
    th, tw = tpl.shape[:2]
    for s in scales:
        w, h = int(round(tw * s)), int(round(th * s))
        if w < 8 or h < 8 or w > roi.shape[1] or h > roi.shape[0]:
            continue
        resized = cv2.resize(tpl, (w, h), interpolation=cv2.INTER_AREA if s < 1 else cv2.INTER_LINEAR)
        res = cv2.matchTemplate(roi, resized, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if max_val > best_val:
            best_val = float(max_val)
            best_box = (max_loc[0] + w / 2.0, max_loc[1] + h / 2.0, w, h)

    if best_box is None or best_val < confidence:
        return None, max(best_val, 0.0)

    px = best_box[0] + x0
    py = best_box[1] + y0
    return mapper.to_screen(px, py), best_val


def locate_with_retry(
    template_path: str,
    confidence: float = 0.85,
    timeout: float = 30.0,
    interval: float = 1.0,
    log=print,
) -> Tuple[Optional[Tuple[int, int]], float]:
    deadline = time.time() + max(timeout, 0.0)
    best = (None, 0.0)
    while True:
        pos, score = locate(template_path, confidence=confidence)
        if pos:
            return pos, score
        if score > best[1]:
            best = (None, score)
        if time.time() >= deadline:
            return None, best[1]
        time.sleep(interval)


# ------------------------------------------------------------------ 输入
def click(x: int, y: int, clicks: int = 1, button: str = "left") -> None:
    pyautogui.click(x, y, clicks=clicks, button=button)


def hotkey(*keys: str) -> None:
    pyautogui.hotkey(*keys)


def press(key: str) -> None:
    pyautogui.press(key)


def write_text(text: str) -> None:
    """支持中文输入：走剪贴板粘贴，避免输入法问题"""
    try:
        import pyperclip  # 可选依赖
        pyperclip.copy(text)
        pyautogui.hotkey("ctrl", "v")
        return
    except Exception:
        pass
    # 退回到 tkinter 剪贴板方案（tkinter 随 Python 自带）
    try:
        import tkinter as _tk

        root = _tk.Tk()
        root.withdraw()
        root.clipboard_clear()
        root.clipboard_append(text)
        root.update()
        root.destroy()
        pyautogui.hotkey("ctrl", "v")
        return
    except Exception:
        pass
    pyautogui.write(text)


def scroll(clicks: int) -> None:
    pyautogui.scroll(clicks)


# ------------------------------------------------------------------ 启动
def launch_app(path: str, args: str = "") -> bool:
    if not path or not os.path.exists(path):
        return False
    import subprocess

    cmd = f'"{path}"'
    if args:
        cmd += " " + args
    workdir = os.path.dirname(path)
    # CREATE_NO_WINDOW：避免 shell=True 弹一下黑框，那个黑框会抢焦点，导致后续点击点空
    subprocess.Popen(cmd, cwd=workdir, shell=True, creationflags=0x08000000)
    return True


def launch_url(url: str, browser: str = "system", browser_path: str = "") -> bool:
    import subprocess
    import webbrowser

    if browser == "system" or not browser_path:
        try:
            webbrowser.open(url)
            return True
        except Exception:
            return False
    try:
        subprocess.Popen([browser_path, url], shell=False)
        return True
    except Exception:
        return False


# ------------------------------------------------------------------ 电源
# 具体实现统一放在 power.py（带返回码校验、失败重试、logs/power.log 记录）
def shutdown(force: bool = True):
    from power import run_shutdown

    return run_shutdown(force)


def sleep_pc():
    from power import _suspend

    return _suspend(False)


def hibernate():
    from power import _suspend

    return _suspend(True)


def cancel_shutdown():
    from power import cancel_shutdown as _cancel

    return _cancel()
