# -*- coding: utf-8 -*-
"""电源动作（关机 / 睡眠 / 休眠）。

以前的实现是 `subprocess.run(cmd, shell=True)`，**不看返回值**——命令失败也悄无声息，
用户只会看到"没关机"。这里改成：抓返回码 + 记录 stderr + 失败自动重试一次，
并且所有结果都写进 logs/power.log，下次能直接看出是哪一步断的。
"""
from __future__ import annotations

import ctypes
import os
import subprocess
import time
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_DIR = os.path.join(BASE_DIR, "logs")
CREATE_NO_WINDOW = 0x08000000


def log(msg: str) -> None:
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(os.path.join(LOG_DIR, "power.log"), "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}\n")
    except Exception:
        pass


def _decode(b: bytes | None) -> str:
    if not b:
        return ""
    for enc in ("gbk", "utf-8"):
        try:
            return b.decode(enc).strip()
        except Exception:
            continue
    return b.decode("utf-8", "ignore").strip()


def run_shutdown(force: bool = True, delay: int = 0) -> tuple[int, str]:
    """调用系统关机命令，返回 (返回码, 输出)。返回码 0 表示命令已被接受。"""
    args = ["shutdown", "/s", "/t", str(max(0, int(delay)))]
    if force:
        args.append("/f")
    try:
        r = subprocess.run(args, capture_output=True, creationflags=CREATE_NO_WINDOW, timeout=30)
        out = (_decode(r.stdout) + " " + _decode(r.stderr)).strip()
        log(f"shutdown 调用 args={args} rc={r.returncode} out={out!r}")
        return r.returncode, out
    except Exception as exc:  # noqa
        log(f"shutdown 调用异常：{exc}")
        return -1, str(exc)


def cancel_shutdown() -> tuple[int, str]:
    try:
        r = subprocess.run(["shutdown", "/a"], capture_output=True,
                           creationflags=CREATE_NO_WINDOW, timeout=30)
        out = (_decode(r.stdout) + " " + _decode(r.stderr)).strip()
        log(f"shutdown /a rc={r.returncode} out={out!r}")
        return r.returncode, out
    except Exception as exc:  # noqa
        log(f"shutdown /a 异常：{exc}")
        return -1, str(exc)


def _suspend(hibernate_mode: bool) -> tuple[bool, str]:
    try:
        ok = ctypes.windll.powrprof.SetSuspendState(1 if hibernate_mode else 0, 0, 0)
        name = "休眠" if hibernate_mode else "睡眠"
        log(f"SetSuspendState({name}) -> {ok}")
        if ok:
            return True, f"{name}命令已发出"
        return False, f"{name}失败（系统可能不支持该电源状态；可用 powercfg /a 查看）"
    except Exception as exc:  # noqa
        log(f"SetSuspendState 异常：{exc}")
        return False, str(exc)


def perform(mode: str) -> tuple[bool, str]:
    """执行电源动作，返回 (是否成功, 说明)。关机失败会重试一次。"""
    log(f"===== 执行电源动作：{mode} =====")
    if mode == "shutdown":
        rc, out = run_shutdown()
        if rc == 0:
            return True, "关机命令已被系统接受"
        log(f"关机首次失败（rc={rc}），3 秒后重试")
        time.sleep(3)
        rc2, out2 = run_shutdown()
        if rc2 == 0:
            return True, "关机命令已被系统接受（第 2 次尝试）"
        return False, f"关机失败：rc={rc2}，{out2 or out}"
    if mode == "sleep":
        return _suspend(False)
    if mode == "hibernate":
        return _suspend(True)
    return True, f"无动作（{mode}）"


if __name__ == "__main__":
    # 手动自检：只查环境，不真的关机
    print("power.py 自检：不执行任何电源动作")
    print("shutdown 命令存在：", bool(subprocess.run(["where", "shutdown"],
                                                 capture_output=True).returncode == 0))
