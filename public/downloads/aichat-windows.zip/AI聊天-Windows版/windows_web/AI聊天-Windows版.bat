@echo off
title AI Chat - Windows
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0serve.ps1"
