# AI Chat - Windows zero-install launcher
# Starts server.exe (concurrent static file server, no admin rights needed)
# and opens the app in an Edge app window with proxy bypass.
$ErrorActionPreference = 'Stop'

$webRoot = Join-Path $PSScriptRoot "..\build\web"
$webRoot = [System.IO.Path]::GetFullPath($webRoot)
if (-not (Test-Path (Join-Path $webRoot "index.html"))) {
    Write-Host "build\web not found. Run 'flutter build web' first." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}
$serverExe = Join-Path $PSScriptRoot "server.exe"
if (-not (Test-Path $serverExe)) {
    Write-Host "server.exe not found." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

# Find a free port
$port = 18765
$probe = $null
while ($true) {
    try {
        $probe = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $port)
        $probe.Start()
        break
    } catch {
        $port++
        if ($port -gt 18800) {
            Write-Host "No free port found." -ForegroundColor Red
            Read-Host "Press Enter to exit"
            exit 1
        }
    }
}
$probe.Stop()

$url = "http://127.0.0.1:$port/?t=$(Get-Date -UFormat %s)"
Write-Host "AI Chat is running at $url"
Write-Host "Close this window to quit."

# Open Edge in app mode with a DEDICATED profile so that:
#  1) command-line flags are always honored (no proxy hijack from system proxy / TUN)
#  2) the app window never inherits the user's normal browsing proxy settings
$edgeCandidates = @(
    (Join-Path ${env:ProgramFiles} 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe')
)
$edge = $edgeCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
$profileDir = Join-Path $PSScriptRoot 'EdgeProfile'
New-Item -ItemType Directory -Force -Path $profileDir | Out-Null
if ($edge) {
    Start-Process $edge -ArgumentList `
        "--app=$url", `
        "--user-data-dir=$profileDir", `
        "--window-size=1200,860", `
        "--proxy-server=direct://", `
        "--proxy-bypass-list=<-loopback>", `
        "--enable-unsafe-swiftshader", `
        "--no-first-run", `
        "--no-default-browser-check"
} else {
    Start-Process $url
}

# Run the concurrent static server in the foreground (closing this window quits it)
& $serverExe $port $webRoot
